<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<title>Profil</title>

	<!-- Favicons -->
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="icon">
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<!--external css-->
	<link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/lib/advanced-datatable/css/demo_page.css')?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/lib/advanced-datatable/css/demo_table.css')?>" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url('assets/lib/advanced-datatable/css/DT_bootstrap.css')?>" />
	<!-- Custom styles for this template -->
	<link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">
</head>

<body>

	<!--header start-->
	<header class="header black-bg">
		<div class="sidebar-toggle-box">
			<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
		</div>
		<!--logo start-->
		<a href="index.html" class="logo"><b>ROCK<span>MASS</span></b></a>
		<!--logo end-->
		<div class="top-menu">
			<ul class="nav pull-right top-menu">
				<li><a class="logout" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
			</ul>
		</div>
	</header>
	<!--header end-->

	<!--sidebar start-->
	<aside>
		<div id="sidebar" class="nav-collapse ">
			<!-- sidebar menu start-->
			<ul class="sidebar-menu" id="nav-accordion">
				<p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/img/employee/'.$picture)?>" class="img-circle" width="80"></a></p>
				<h5 class="centered"><?php echo $name ?></h5>
				<li class="mt">
					<a href="<?php echo site_url('Home')?>">
						<i class="fa fa-dashboard"></i>
						<span>Home</span>
					</a>
				</li>

				<li class="sub-menu">
					<a href="<?php echo site_url('Show/view_data')?>">
						<i class="fa fa-th"></i>
						<span>Data</span>
					</a>
				</li>

				<li class="sub-menu">
					<a href="<?php echo site_url('Home/calculation_form')?>">
						<i class="fa fa-calculator"></i>
						<span>Calculation</span>
					</a>
				</li>

				<li class="sub-menu">
					<a class="active" href="<?php echo site_url('User/show_profil')?>">
						<i class="fa fa-cog"></i>
						<span>Profil</span>
					</a>
				</li>
			</ul>
			<!-- sidebar menu end-->
		</div>
	</aside>

	<section id="main-content">
		<section class="wrapper site-min-height">
			<div class="row mt">
				<div class="col-lg-12">
					<div class="row content-panel">
						<div class="col-md-4 profile-text mt mb centered">
							<div class="right-divider hidden-sm hidden-xs">
								<h3><?php echo $position; ?></h3>
							</div>
						</div>
						<!-- /col-md-4 -->
						<div class="col-md-4 profile-text">
							<h3><?php echo $name; ?></h3>
							<h6><?php echo $employee_number; ?></h6>
							<p><?php echo $email; ?></p>
							<p><?php echo $address; ?></p>
						</div>
						<!-- /col-md-4 -->
						<div class="col-md-4 centered">
							<div class="profile-pic">
								<p><img src="<?php echo base_url('assets/img/employee/'.$picture)?>" class="img-circle"></p>
							</div>
						</div>
						<!-- /col-md-4 -->
					</div>
					<div class="col-lg-12 mt">
						<div class="row content-panel">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-8 col-lg-offset-2 detailed">
										<h4 class="mb">Edit Personal Information</h4>
										<form role="form" class="form-horizontal" method="POST" action="<?php echo site_url('User/edit_data') ?>">
											<input type="hidden" name="username" value="<?php echo $username ?>">
											<input type="hidden" name="password" value="<?php echo $password ?>">
											<div class="form-group">
												<label class="col-lg-2 control-label">Avatar</label>
												<div class="col-lg-6">
													<input type="file" id="exampleInputFile" class="file-pos" name="picture">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Username</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="c-name" class="form-control" name="username" value="<?php echo $username ?>" readonly>
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Name</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="lives-in" class="form-control" name="name" value="<?php echo $name ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Employee Number</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="country" class="form-control" name="employee_number" value="<?php echo $employee_number ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Position</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="country" class="form-control" name="position" value="<?php echo $position ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Email</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="country" class="form-control" name="email" value="<?php echo $email ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Phone</label>
												<div class="col-lg-6">
													<input type="text" placeholder=" " id="country" class="form-control" name="phone" value="<?php echo $phone ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-lg-2 control-label">Address</label>
												<div class="col-lg-10">
													<textarea rows="10" cols="30" class="form-control" id="" name="address"><?php echo $address ?></textarea>
												</div>
											</div>
											<div class="form-group">
												<div class="col-lg-offset-2 col-lg-10">
													<button class="btn btn-theme" type="submit">Save</button>
													<button class="btn btn-theme04" type="reset">Cancel</button>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</section>

	<!--footer start-->
	<footer class="site-footer">
		<div class="text-center">
			<p>
				&copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
			</p>
			<div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
        -->
        Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
    </div>
    <a href="profile.html#" class="go-top">
    	<i class="fa fa-angle-up"></i>
    </a>
</div>
</footer>
<!--footer end-->
</section>
<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
<script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
<script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
<script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
<script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
<!--common script for all pages-->
<script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
<!--script for this page-->

</body>
</html>