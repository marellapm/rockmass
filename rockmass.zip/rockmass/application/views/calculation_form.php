<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Dashio - Bootstrap Admin Template</title>

  <!-- Favicons -->
  <link href="<?php echo base_url('assets/img/logo.png" rel="icon')?>">
  <link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-datepicker/css/datepicker.css')?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-daterangepicker/daterangepicker.css')?>" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
          <div class="sidebar-toggle-box">
            <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
          </div>
          <!--logo start-->
          <a href="index.html" class="logo"><b>ROCK<span>MASS</span></b></a>
          <!--logo end-->
          <div class="top-menu">
            <ul class="nav pull-right top-menu">
              <li><a class="logout" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
            </ul>
          </div>
        </header>
        <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
          <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu" id="nav-accordion">
              <p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/img/employee/'.$pict)?>" class="img-circle" width="80"></a></p>
              <h5 class="centered"><?php echo $nama; ?></h5>
              <li class="mt">
                <a href="<?php echo site_url('Home')?>">
                  <i class="fa fa-dashboard"></i>
                  <span>Home</span>
                </a>
              </li>

              <li class="sub-menu">
                <a href="<?php echo site_url('Show/view_data')?>">
                  <i class="fa fa-th"></i>
                  <span>Data</span>
                </a>
              </li>

              <li class="sub-menu">
                <a class="active" href="<?php echo site_url('Home/calculation_form')?>">
                  <i class="fa fa-calculator"></i>
                  <span>Calculation</span>
                </a>
              </li>

              <li class="sub-menu">
                <a href="<?php echo site_url('User/show_profil')?>">
                  <i class="fa fa-cog"></i>
                  <span>Profil</span>
                </a>
              </li>
            </ul>
            <!-- sidebar menu end-->
          </div>
        </aside>
        <!--sidebar end-->

        <!--main content start-->
        <section id="main-content">
          <section class="wrapper">
            <h3><i class="fa fa-angle-right"></i> Form Calculation</h3>
            <div class="row mt">
             <div class="col-sm-12">
              <section class="form-panel">
                <form class="form-horizontal style-form" method="POST" action="<?php echo site_url('Calculation/calculate') ?>">
                  <input type="hidden" name="id">
                  <!--RQD-->
                  <div class="form-group" id="collapse-rqd" data-toggle="collapse" href="#collapserqd">
                    <label class="col-sm-3 col-sm-3 control-label">Rock Quality Designation (RQD)</label>
                    <div class="col-sm-9">
                      <input type="text" name="rqd" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapserqd" class="collapse" data-parent="collapse-rqd">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>RQD (%)</th>
                            <th>Quality</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($rqd as $rqd) : ?>
                            <tr>
                              <td> <?php echo $rqd->rqd; ?> </td>
                              <td> <?php echo $rqd->quality; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div> 

                  <div class="form-group" id="collapse-jn" data-toggle="collapse" href="#collapsejn">
                    <label class="col-sm-3 col-sm-3 control-label">Joint Set Numbaer (Jn)</label>
                    <div class="col-sm-9">
                      <input type="text" name="jn" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapsejn" class="collapse" data-parent="collapse-jn">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Description</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($jn as $jn) : ?>
                            <tr>
                              <td> <?php echo $jn->jn_description; ?> </td>
                              <td> <?php echo $jn->jn_value; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group" id="collapse-jr" data-toggle="collapse" href="#collapsejr">
                    <label class="col-sm-3 col-sm-3 control-label">Joint Roughness Number (Jr)</label>
                    <div class="col-sm-9">
                      <input type="text" name="jr" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapsejr" class="collapse" data-parent="collapse-jr">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Description</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($jr as $jr) : ?>
                            <tr>
                              <td> <?php echo $jr->jr_description; ?> </td>
                              <td> <?php echo $jr->jr_value; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group" id="collapse-ja" data-toggle="collapse" href="#collapseja">
                    <label class="col-sm-3 col-sm-3 control-label">Joint Alteration Number (Ja)</label>
                    <div class="col-sm-9">
                      <input type="text" name="ja" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapseja" class="collapse" data-parent="collapse-ja">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Description</th>
                            <th>Value</th>
                            <th>Approx&deg</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($ja as $ja) : ?>
                            <tr>
                              <td> <?php echo $ja->ja_description; ?> </td>
                              <td> <?php echo $ja->ja_value; ?> </td>
                              <td> <?php echo $ja->ja_approx; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group" id="collapse-jw" data-toggle="collapse" href="#collapsejw">
                    <label class="col-sm-3 col-sm-3 control-label">Joint Water Reduction Number (Jw)</label>
                    <div class="col-sm-9">
                      <input type="text" name="jw" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapsejw" class="collapse" data-parent="collapse-jw">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Code</th>
                            <th>Description</th>
                            <th>Value</th>
                            <th>Water Pressure</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($jw as $jw) : ?>
                            <tr>
                              <td> <?php echo $jw->jw_kode; ?> </td>
                              <td> <?php echo $jw->jw_description; ?> </td>
                              <td> <?php echo $jw->jw_value; ?> </td>
                              <td> <?php echo $jw->jw_water_press; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group" id="collapse-srf" data-toggle="collapse" href="#collapsesrf">
                    <label class="col-sm-3 col-sm-3 control-label">Stress Reduction Factor (SRF)</label>
                    <div class="col-sm-9">
                      <input type="text" name="srf" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapsesrf" class="collapse" data-parent="collapse-srf">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Code</th>
                            <th>Description</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($srf as $srf) : ?>
                            <tr>
                              <td> <?php echo $srf->srf_kode; ?> </td>
                              <td> <?php echo $srf->srf_description; ?> </td>
                              <td> <?php echo $srf->srf_value; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group" id="collapse-esr" data-toggle="collapse" href="#collapseesr">
                    <label class="col-sm-3 col-sm-3 control-label">Excavation Support Ratio (ESR)</label>
                    <div class="col-sm-9">
                      <input type="text" name="esr" class="form-control round-form" required>
                    </div>
                  </div>
                  <div id="collapseesr" class="collapse" data-parent="collapse-esr">
                    <div class="panel-body">
                      <table align="center" class="table">
                        <thead>
                          <tr>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($esr as $esr) : ?>
                            <tr>
                              <td> <?php echo $esr->esr_category; ?> </td>
                              <td> <?php echo $esr->esr_description; ?> </td>
                              <td> <?php echo $esr->esr_value; ?> </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 col-sm-3 control-label">Span Height (on meters)</label>
                    <div class="col-sm-9">
                      <input type="text" name="b" class="form-control round-form" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 col-sm-3 control-label">Location</label>
                    <div class="col-sm-9">
                      <input type="text" name="location" class="form-control round-form" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-lg-offset-5 col-lg-10">
                      <button class="btn btn-theme" type="submit">Done</button>
                      <button class="btn btn-theme04" type="reset">Cancel</button>
                    </div>
                  </div>

                </form>
              </section>
            </div>
          </div>
        </section>
      </section>
      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
        <div class="text-center">
          <p>
            &copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
          </p>
          <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
        </a>
      </div>
    </footer>
    <!--footer end-->
  </section>



  <div class="copyright py-4 text-center text-white">
    <div class="container">
      <small>Copyright © Your Website 2019</small>
    </div>
  </div>

  <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
  <div class="scroll-to-top d-lg-none position-fixed " style="display: block;">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
      <i class="fa fa-chevron-up"></i>
    </a>
  </div>

  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
  <script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
  <script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
  <script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
  <!--script for this page-->
  <script src="<?php echo base_url('assets/lib/form-validation-script.js')?>"></script>

  <!--COLLAPSE-->
  <script type="text/javascript">
    //mouse over navbar
    $('.navbar').mouseover(function(event) {
      $(this).find('.navbar-tool').show();
    });

    //mouse out of navbar
    $('.navbar').mouseout(function(event) {
      $(this).find('.navbar-tool').hide();
    });

    //on close collapse
    $('.collapse').on('hidden.bs.collapse', function () {
      var target = '#'+$(this).attr('data-parent');
      $(target).removeClass('collapse-open');
    });

    //on open collapse
    $('.collapse').on('shown.bs.collapse', function () {
      var target = '#'+$(this).attr('data-parent');
      $(target).addClass('collapse-open');
    })

  </script>

</body>

</html>
