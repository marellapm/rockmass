<?php
$i=0;
foreach ($table as $table) {
	if($table->id != $id) {
		$dataPoints1[$i]['x'] = (float)$table->qresult;
		$dataPoints1[$i]['y'] = (float)$table->rmr_result;
		$dataPoints1[$i]['loc'] = $table->location;
		$i++;
	}
}

$dataPoints2 = array(
	array("x" => (float)$q, "y" => (float)$rmr, "loc" => $location),
);

?>

<!DOCTYPE html>
<html>
<head>
	<style type="text/css"></style>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<title>Result</title>

	<!-- Favicons -->
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="icon">
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<!--external css-->
	<link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
	<!-- Custom styles for this template -->
	<link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">

	<script>
		window.onload = function () {

			var chart = new CanvasJS.Chart("chartContainer", {
				animationEnabled: true,
				axisX: {
					title:"Rock Mass Quality = Q-System"
				},
				axisY:{
					title: "Rock Mass Rating = RMR"
				},
				legend:{
					cursor: "pointer",
					itemclick: toggleDataSeries
				},
				data: [
				{
					type: "scatter",
					toolTipContent: "<span style=\"color:#4F81BC \"><b>{name}</b></span><br/><b> Location:</b></span> {loc}<br/><b> Q:</b> {x}<br/><b> RMR:</b></span> {y}",
					name: "Data",
					markerType: "square",
					showInLegend: true,
					dataPoints: <?php echo json_encode($dataPoints1); ?>
				},
				{
					type: "scatter",
					name: "Data Selected",
					markerType: "triangle",
					showInLegend: true, 
					toolTipContent: "<span style=\"color:#C0504E \"><b>{name}</b></span><br/><b> Location:</b></span> {loc}<br/><b> Q:</b> {x}<br/><b> RMR:</b></span> {y}",
					dataPoints: <?php echo json_encode($dataPoints2); ?>
				}
				]
			});

			chart.render();

			function toggleDataSeries(e){
				if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
					e.dataSeries.visible = false;
				}
				else{
					e.dataSeries.visible = true;
				}
				chart.render();
			}

		}
	</script>
</head>

<body>

	<section id="container">
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
			<a href="index.html" class="logo"><b>ROCK<span>MASS</span></b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
					<li><a class="logout" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->
		\
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">
					<p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/img/employee/'. $pict)?>" class="img-circle" width="80"></a></p>
					<h5 class="centered"><?php echo $nama ?></h5>
					<li class="mt">
						<a href="<?php echo site_url('Home')?>">
							<i class="fa fa-dashboard"></i>
							<span>Home</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('Show/view_data')?>">
							<i class="fa fa-th"></i>
							<span>Data</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="<?php echo site_url('Home/calculation_form')?>">
							<i class="fa fa-calculator"></i>
							<span>Calculation</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('User/show_profil')?>">
							<i class="fa fa-cog"></i>
							<span>Profil</span>
						</a>
					</li>
				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>

		<section id="main-content">
			<section class="wrapper">
				<h3><i class="fa fa-angle-right"></i> RMR Result </h3>
				<h4>Location : <?php echo "$location"; ?></h4>
				<div class="panel panel-default text-center">
					<div class="panel-heading">DETAIL INPUT</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">RQD</p>
								<p><h3><?php echo $rqd ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Set Number</p>
								<p><h3><?php echo $jn ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Joint Alteration Number</p>
								<p><h3><?php echo $ja ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Water Reduction</p>
								<p><h3><?php echo $jw ?></h3></p>
							</div>
						</div>

						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Roughness Number</p>
								<p><h3><?php echo $jr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Stress Reduction Factor</p>
								<p><h3><?php echo $srf ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Excavation Support Ratio</p>
								<p><h3><?php echo $esr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Lebar Galian (m)</p>
								<p><h3><?php echo $b ?></h3></p>
							</div>
						</div>
					</div>
				</div>

				

				<div class="panel panel-default text-center">
					<div class="panel-heading">Q-System and RMR Recomendation</div>
					<div class="panel-body">
						<div class="row">
							<table align="center" class="table">
								<tr>
									<td width="400px"><h5><b>Q-System Recomendation</b></h5></td>
									<td width="400px"><h5><b>RMR Recomendation</b></h5></td>
								</tr>
								<tr align="left">
									<td> Rockbolt : <br>
										<?php echo "Panjang Rockbolt yang digunakan adalah ".$l." m"; ?> <br> <br>
										Support Type : <br>
										<?php echo "$support_type"; ?><br><br>
										Notes : <?php foreach ($notes_table as $note) {
											echo "<h5> ( $note->notes_number ) $note->notes<br><br> </h5>";
										} ?>
									</td>
									<td><?php echo "Rockbolt : <br>$rmr_table->rockbolt"; ?> <br> <br>
										<?php echo "Shotcrete : <br>$rmr_table->shotcrete"; ?> <br> <br>
										<?php echo "Steel Sets : <br>$rmr_table->steelsets"; ?>
									</td>
								</tr>
							</table>
							<a href="#detail" id="collapse-detail" data-toggle="collapse">>>See details<<</a>
						</div>
					</div>
				</div>

				<div id="detail" class="collapse" data-parent="collapse-detail">
					<div class="panel panel-default text-center">
						<div class="panel-heading">RECOMENDATION</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6 col-xs-6">
									<p class="medium mt"><h1>Q-System</h1></p>
									<p><h4> <table align="center" class="table">
										<tr align="left">
											<td> Q Value</td>
											<td> : </td>
											<td>
												<?php if (strlen($q)>6) {
													echo number_format($q,3);
												} else {
													echo $q;
												} ?>	
											</td>
										</tr>
										<tr align="left">
											<td> Q Classification </td>
											<td> : </td>
											<td> <?php echo "$q_classification"; ?> </td>
										</tr>
										<tr align="left">
											<td> Q Class</td>
											<td> : </td>
											<td> <?php echo "$qarea"; ?> </td>
										</tr>
										<tr align="left">
											<td> Support Type</td>
											<td> : </td>
											<td> <?php echo "$support_type"; ?> </td>
										</tr>
										<tr align="left">
											<td> Rockbolt (L) </td>
											<td> : </td>
											<td>
												<?php if (strlen($l)>6) { 
													echo number_format($l,3)." m";
												} else {
													echo $l." m";
												} ?>
											</td>
										</tr>
										<tr align="left">
											<td> Max Unsupported Span </td>
											<td> : </td>
											<td>
												<?php if (strlen($spanmax)>6) {
													echo number_format($spanmax,3)." m";
												} else {
													echo $spanmax;
												} ?>
											</td>
										</tr>
										<tr align="left">
											<td> Equivalent Dimension (ED) </td>
											<td> : </td>
											<td>
												<?php if((strlen($ed))>6) {
													echo number_format($ed,3);
												} else {
													echo $ed;
												} ?>
											</td>
										</tr>
										<tr align="left">
											<td> P roof </td>
											<td> : </td>
											<td>
												<?php if (strlen($p_roof)>6) {
													echo number_format($p_roof,3)." ton/m<sup>2</sup>";
												} else {
													echo $p_roof;
												} ?>
											</td>
										</tr>
										<tr align="left">
											<td> RQD/Jn </td>
											<td> : </td>
											<td>
												<?php if(strlen($conditional_a)>6) {
													echo number_format($conditional_a,3);
												} else {
													echo $conditional_a;
												} ?>

											</td>
										</tr>
										<tr align="left">
											<td> Jr/Ja </td>
											<td> : </td>
											<td>
												<?php if(strlen($conditional_b)>6) {
													echo number_format($conditional_b,3);
												} else {
													echo $conditional_b;
												} ?>
											</td>
										</tr>
										<tr align="left">
											<td> Notes </td>
											<td> : </td>
											<td> <?php foreach ($notes_table as $note) {
												echo "<h5> ( $note->notes_number ) $note->notes<br><br> </h5>";
											} ?> </td>
										</tr>
									</table></h4>
									<h4 align="left">Notes<br></h4>
									<h5 align="left">
										(sb)	: Spot Bolting <br>
										(B)		: Systematic Bolting (m) <br>
										(utg)	: Untensioned, Grounted <br>
										(tg)	: Tensioned <br>
										(S)		: Shotcrete (cm) <br>
										(mr)	: Mesh-reinforced <br>
										(clm)	: Chain-link Mesh <br>
										(CCA)	: Cast Concrete arch (cm) <br>
										(sr)	: Steel-reinforced <br>
									</h5></p>
								</div>
								<div class="col-md-6 col-xs-6">
									<p class="medium mt"><h1>RMR</h1></p>
									<p><h4> <table align="center" class="table">
										<tr align="left">
											<td> RMR Type</td>
											<td> : </td>
											<td> <?php echo "$rmrtype"; ?> </td>
										</tr>
										<tr align="left">
											<td> RMR Value</td>
											<td> : </td>
											<td> <?php echo number_format($rmr,3); ?> </td>
										</tr>
										<tr align="left">
											<td> RMR Class</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->rmr_class"; ?> </td>
										</tr>
										<tr align="left">
											<td> RMR Classification</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->rmr_classification"; ?> </td>
										</tr>
										<tr align="left">
											<td> Average Stand</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->avg_stand"; ?> </td>
										</tr>
										<tr align="left">
											<td> Cohession</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->cohession"; ?> MPa </td>
										</tr>
										<tr align="left">
											<td> Angle</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->angle &deg"; ?> </td>
										</tr>
										<tr align="left">
											<td> Allowable Bearing Pressure </td>
											<td> : </td>
											<td> <?php echo "$rmr_table->bearing_pressure"; ?> (T/m<sup>2</sup>) </td>
										</tr>
										<tr align="left">
											<td> Cut Slope</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->cut_slope &deg"; ?> </td>
										</tr>
										<tr align="left">
											<td> Penggalian</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->penggalian"; ?> </td>
										</tr>
										<tr align="left">
											<td> Rockbolt</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->rockbolt"; ?> </td>
										</tr>
										<tr align="left">
											<td> Shotcrete</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->shotcrete"; ?> </td>
										</tr>
										<tr align="left">
											<td> Steelsets</td>
											<td> : </td>
											<td> <?php echo "$rmr_table->steelsets"; ?> </td>
										</tr>
									</table></h4></p>
								</div>
							</div>
						<!--<?php //if(($rmr_table->rmr_class=="0") and ($qarea=="0") and ($rmr<40)) {
							//echo "<h4> Tidak dapat dilakukan penggalian </h4>";
						//} else if(($rmr_table->rmr_class=="0") and ($qarea=="0") and ($rmr>=40)) {
							//echo "<h4> Tidak memerlukan penyanggaan </h4>";
						//} ?> -->
					</div>
				</div>
			</div>

			<div class="panel panel-default text-center">
				<div class="panel-heading">Q-System and RMR Corelation</div>
				<div class="panel-body">
					<div class="row">
						<div class="tab-pane" id="chartjs">
							<center><div id="chartContainer" style="height: 370px; width: 90%;"></div></center>
						</div>
					</div>
				</div>
			</div>

			<form method="POST" action="<?php echo site_url('Home/save_data') ?>">
				<input type="hidden" name="location" value="<?php echo $location ?>">
				<input type="hidden" name="rqd" value="<?php echo $rqd ?>">
				<input type="hidden" name="jn" value="<?php echo $jn ?>">
				<input type="hidden" name="jr" value="<?php echo $jr ?>">
				<input type="hidden" name="ja" value="<?php echo $ja ?>">
				<input type="hidden" name="jw" value="<?php echo $jw ?>">
				<input type="hidden" name="srf" value="<?php echo $srf ?>">
				<input type="hidden" name="esr" value="<?php echo $esr ?>">
				<input type="hidden" name="b" value="<?php echo $b ?>">
				<input type="hidden" name="ed" value="<?php echo $ed ?>">
				<input type="hidden" name="qresult" value="<?php echo $q ?>">
				<input type="hidden" name="rmr_type" value="<?php echo $rmrtype ?>">
				<input type="hidden" name="rmr_result" value="<?php echo $rmr ?>">
				<input type="hidden" name="l" value="<?php echo $l ?>">
				<input type="hidden" name="spanmax" value="<?php echo $spanmax ?>">
				<input type="hidden" name="p_roof" value="<?php echo $p_roof ?>">
				<input type="hidden" name="cond_a" value="<?php echo $conditional_a ?>">
				<input type="hidden" name="cond_b" value="<?php echo $conditional_b ?>">
				<input type="hidden" name="q_table" value="<?php echo $q_table ?>">
				<input type="hidden" name="rmr_table" value="<?php echo $rmr_table->id_rmr ?>">

				<div class="form-group">
					<button type="submit" class="btn btn-primary btn-xl" id="sendMessageButton">Save To Database</button>
				</div>
			</form>
		</section>
	</section>

	<!--footer start-->
	<footer class="site-footer">
		<div class="text-center">
			<p>
				&copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
			</p>
			<div class="credits">
				Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
			</div>
			<a href="index.html#" class="go-top">
				<i class="fa fa-angle-up"></i>
			</a>
		</div>
	</footer>
	<!--footer end-->

</section>

<!-- Bootstrap core JavaScript -->
<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
<script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
<script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
<script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
<script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
<!--common script for all pages-->
<script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
<!--script for this page-->
<script src="<?php echo base_url('assets/lib/chart-master/Chart.js')?>"></script>
<script src="<?php echo base_url('assets/lib/chartjs-conf.js')?>"></script>

<script src="<?php echo base_url('assets/lib/bubblechart.js') ?>"></script>
</body>
</html>