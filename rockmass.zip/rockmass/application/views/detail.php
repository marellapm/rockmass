<?php
$i=0;
foreach ($table as $table) {
	if($table->id != $detail->id) {
		$dataPoints1[$i]['x'] = (float)$table->qresult;
		$dataPoints1[$i]['y'] = (float)$table->rmr_result;
		$dataPoints1[$i]['loc'] = $table->location;
		$i++;
	}

	if ($i==0) {
		$dataPoints1=NULL;
	}
}

$dataPoints2 = array(
	array("x" => (float)$detail->qresult, "y" => (float)$detail->rmr_result, "loc" => $detail->location),
);
?>

<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<title>Detail Data</title>

	<!-- Favicons -->
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="icon">
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<!--external css-->
	<link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
	<!-- Custom styles for this template -->
	<link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">
	<script>
		window.onload = function () {

			var chart = new CanvasJS.Chart("chartContainer", {
				animationEnabled: true,
				axisX: {
					title:"Rock Mass Quality = Q-System"
				},
				axisY:{
					title: "Rock Mass Rating = RMR"
				},
				legend:{
					cursor: "pointer",
					itemclick: toggleDataSeries
				},
				data: [
				{
					type: "scatter",
					toolTipContent: "<span style=\"color:#4F81BC \"><b>{name}</b></span><br/><b> Location:</b></span> {loc}<br/><b> Q:</b> {x}<br/><b> RMR:</b></span> {y}",
					name: "Data",
					markerType: "square",
					showInLegend: true,
					dataPoints: <?php echo json_encode($dataPoints1); ?>
				},
				{
					type: "scatter",
					name: "Data Selected",
					markerType: "triangle",
					showInLegend: true, 
					toolTipContent: "<span style=\"color:#C0504E \"><b>{name}</b></span><br/><b> Location:</b></span> {loc}<br/><b> Q:</b> {x}<br/><b> RMR:</b></span> {y}",
					dataPoints: <?php echo json_encode($dataPoints2); ?>
				}
				]
			});

			chart.render();

			function toggleDataSeries(e){
				if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
					e.dataSeries.visible = false;
				}
				else{
					e.dataSeries.visible = true;
				}
				chart.render();
			}

		}
	</script>
</head>

<body>
	<section id="container">
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
			<a href="index.html" class="logo"><b>ROCK<span>MASS</span></b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
					<li><a class="logout" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->
		
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">
					<p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/img/employee/'.$pict)?>" class="img-circle" width="80"></a></p>
					<h5 class="centered"><?php echo $nama ?></h5>
					<li class="mt">
						<a href="<?php echo site_url('Home')?>">
							<i class="fa fa-dashboard"></i>
							<span>Home</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="<?php echo site_url('Show/view_data')?>">
							<i class="fa fa-th"></i>
							<span>Data</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('Home/calculation_form')?>">
							<i class="fa fa-calculator"></i>
							<span>Calculation</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('User/show_profil')?>">
							<i class="fa fa-cog"></i>
							<span>Profil</span>
						</a>
					</li>
				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>
		<!--sidebar end-->

		<!--main content start-->
		<section id="main-content">
			<section class="wrapper">
				<h3><i class="fa fa-angle-right"></i> Detail Data</h3>
				<h4>Location : <?php echo "$detail->location"; ?></h4>
				<div class="panel panel-default text-center">
					<div class="panel-heading">DETAIL INPUT</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">RQD</p>
								<p><h3><?php echo $detail->rqd ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Set Number</p>
								<p><h3><?php echo $detail->jn ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Joint Alteration Number</p>
								<p><h3><?php echo $detail->ja ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Water Reduction</p>
								<p><h3><?php echo $detail->jw ?></h3></p>
							</div>
						</div>

						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Roughness Number</p>
								<p><h3><?php echo $detail->jr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Stress Reduction Factor</p>
								<p><h3><?php echo $detail->srf ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Excavation Support Ratio</p>
								<p><h3><?php echo $detail->esr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Lebar Galian (m)</p>
								<p><h3><?php echo $detail->b ?></h3></p>
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-default text-center">
					<div class="panel-heading">Q-System and RMR Recomendation</div>
					<div class="panel-body">
						<div class="row">
							<table align="center" class="table">
								<tr>
									<td width="400px"><h5><b>Q-System Recomendation</b></h5></td>
									<td width="400px"><h5><b>RMR Recomendation</b></h5></td>
								</tr>
								<tr align="left">
									<td> Rockbolt : <br>
										<?php echo "Panjang Rockbolt yang digunakan adalah "."$detail->l"." m"; ?> <br> <br>
										Support Type : <br>
										<?php echo "$detail->type_of_support"; ?><br><br>
										Notes : <?php foreach ($notes_table as $note) {
											echo "<h5> ( $note->notes_number ) $note->notes<br><br> </h5>";
										} ?>
									</td>
									<td><?php echo "Rockbolt : <br>$detail->rockbolt"; ?> <br> <br>
										<?php echo "Shotcrete : <br>$detail->shotcrete"; ?> <br> <br>
										<?php echo "Steel Sets : <br>$detail->steelsets"; ?>
									</td>
								</tr>
							</table>
							<a href="#detail" id="collapse-detail" data-toggle="collapse">>>See details<<</a>
						</div>
					</div>
				</div>
				
				<div id="detail" class="collapse" data-parent="collapse-detail">
					<div class="panel panel-default text-center">
						<div class="panel-heading">RECOMENDATION DETAILS</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6 col-xs-12">
									<p class="medium mt"><h1>Q-System</h1></p>
									<p><h4> <div class="table-responsive">
										<table align="center" class="table">
											<tr align="left">
												<td> Q Value</td>
												<td> : </td>
												<td> <?php echo "$detail->qresult"; ?> </td>
											</tr>
											<tr align="left">
												<td> Q Class</td>
												<td> : </td>
												<td> <?php echo "$detail->support_category"; ?> </td>
											</tr>
											<tr align="left">
												<td> Q Classification </td>
												<td> : </td>
												<td> <?php echo "$q_classification"; ?> </td>
											</tr>
											<tr align="left">
												<td> Support Type</td>
												<td> : </td>
												<td> <?php echo "$detail->type_of_support"; ?> </td>
											</tr>
											<tr align="left">
												<td> Rockbolt (L) </td>
												<td> : </td>
												<td>
													<?php if(strlen($detail->l)>6) {
														echo number_format($detail->l,3)." m";
													} else {
														echo $detail->l;
													} ?>
												</td>
											</tr>
											<tr align="left">
												<td> Max Unsupported Span </td>
												<td> : </td>
												<td>
													<?php if(strlen($detail->spanmax)>6) {
														echo number_format($detail->spanmax,3)." m";
													} else {
														echo $detail->spanmax." m";
													} ?>
												</td>
											</tr>
											<tr align="left">
												<td> Equivalent Dimension (ED) </td>
												<td> : </td>
												<td>
													<?php if(strlen($detail->ed)>6) {
														echo number_format($detail->ed,3);
													} else {
														echo $detail->ed;
													} ?>
												</td>
											</tr>
											<tr align="left">
												<td> P roof </td>
												<td> : </td>
												<td> <?php if(strlen($detail->p_roof)>6) {
													echo number_format($detail->p_roof,3)." ton/m<sup>2</sup>";
												} else {
													echo $detail->p_roof." ton/m<sup>2</sup>";
												} ?> </td>
											</tr>
											<tr align="left">
												<td> RQD/Jn </td>
												<td> : </td>
												<td>
													<?php if(strlen($detail->cond_a)>6) {
														echo number_format($detail->cond_a,3);
													} else {
														echo $detail->cond_a;
													} ?> 
												</td>
											</tr>
											<tr align="left">
												<td> Jr/Jn </td>
												<td> : </td>
												<td>
													<?php if(strlen($detail->cond_b)>6) {
														echo number_format($detail->cond_b,3);
													} else {
														echo $detail->cond_b;
													} ?> 
												</td>
											</tr>

											<tr align="left">
												<td> Notes </td>
												<td> : </td>
												<td> <?php foreach ($notes_table as $note) {
													echo "<h5> ( $note->notes_number ) $note->notes<br><br> </h5>";
												} ?> </td>
											</tr>
										</table>
									</div></h4></p>
								</div>
								<div class="col-md-6 col-xs-12">
									<p class="medium mt"><h1>RMR</h1></p>
									<p><h4>
										<div class="table-responsive">
											<table align="center" class="table">
												<tr align="left">
													<td> RMR Value</td>
													<td> : </td>
													<td> 
														<?php if(strlen($detail->rmr_result)>6) {
															echo number_format($detail->rmr_result,3);
														} else {
															echo "$detail->rmr_result";
														} ?> 
													</td>
												</tr>
												<tr align="left">
													<td> RMR Class</td>
													<td> : </td>
													<td> <?php echo "$detail->rmr_class"; ?> </td>
												</tr>
												<tr align="left">
													<td> RMR Classification</td>
													<td> : </td>
													<td> <?php echo "$detail->rmr_classification"; ?> </td>
												</tr>
												<tr align="left">
													<td> RMR Type</td>
													<td> : </td>
													<td> <?php echo "$detail->rmr_type"; ?> </td>
												</tr>
												<tr align="left">
													<td> Average Stand</td>
													<td> : </td>
													<td> <?php echo "$detail->avg_stand"; ?> </td>
												</tr>
												<tr align="left">
													<td> Cohession</td>
													<td> : </td>
													<td> <?php echo "$detail->cohession"; ?> </td>
												</tr>
												<tr align="left">
													<td> Angle</td>
													<td> : </td>
													<td> <?php echo "$detail->angle &deg"; ?> </td>
												</tr>
												<tr align="left">
													<td> Bearing Pressure </td>
													<td> : </td>
													<td> <?php echo "$detail->bearing_pressure"; ?> </td>
												</tr>
												<tr align="left">
													<td> Cut Slope</td>
													<td> : </td>
													<td> <?php echo "$detail->cut_slope &deg"; ?> </td>
												</tr>
												<tr align="left">
													<td> Excavation</td>
													<td> : </td>
													<td> <?php echo "$detail->penggalian"; ?> </td>
												</tr>
												<tr align="left">
													<td> Rockbolt</td>
													<td> : </td>
													<td> <?php echo "$detail->rockbolt"; ?> </td>
												</tr>
												<tr align="left">
													<td> Shotcrete</td>
													<td> : </td>
													<td> <?php echo "$detail->shotcrete"; ?> </td>
												</tr>
												<tr align="left">
													<td> Steelsets</td>
													<td> : </td>
													<td> <?php echo "$detail->steelsets"; ?> </td>
												</tr>
											</table>
										</div></h4></p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="panel panel-default text-center">
						<div class="panel-heading">Q-System and RMR Corelation</div>
						<div class="panel-body">
							<div class="row">
								<div class="tab-pane" id="chartjs">
									<center><div id="chartContainer" style="height: 370px; width: 90%;"></div></center>
								</div>
							</div>
						</div>
					</div>

					<br>
					<a href="<?php echo site_url('Edit/show_form_edit?id='.$detail->id) ?>" data-toggle="bootbox" class="btn btn-primary" role="button">Edit</a>
					<a data-toggle="modal" data-target="#delete" class="btn btn-danger" role="button"> Delete </a>

					<br><br><br>

					<!-- Modal -->
					<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel">Confirm Delete</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body">
									Are you sure want to delete this data?
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
									<a href="<?php echo site_url('Home/delete_data?id='.$detail->id) ?>" class="btn btn-danger" role="button"> Delete </a>
								</div>
							</div>
						</div>
					</div>
				<!--
				
				RQD = $rqd <br>
				Joint Set Number = $jn <br>
				Joint Roughness Number = $jr <br>
				Joint Alteration Number = $ja <br>
				Joint Water Reduction = $jw <br>
				Stress Reduction Factor = $srf <br>
				Excavation Support Ratio = $esr <br> <br>
				Q Result = $q <br>
				Span = $span <br>
				ED = $ed <br>
				P roof = $p_roof <br>
				Conditional A = $cond_a <br>
				Conditional B = $cond_b <br>
				Area = $qarea <br>
				Table = $kode <br>
				Support Type = $support_type_result <br>
				Notes = $notes <br>
				Classification = $notes
				"; ?> -->
			</section>
		</section>
		<!--main content end-->
		<!--footer start-->
		<footer class="site-footer">
			<div class="text-center">
				<p>
					&copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
				</p>
				<div class="credits">
					Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
				</div>
				<a href="index.html#" class="go-top">
					<i class="fa fa-angle-up"></i>
				</a>
			</div>
		</footer>
		<!--footer end-->
	</section>


	<!-- Bootstrap core JavaScript -->
	<!-- js placed at the end of the document so the pages load faster -->
	<script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
	<script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
	<script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
	<script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
	<script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
	<!--common script for all pages-->
	<script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
	<!--script for this page-->
	<script src="<?php echo base_url('assets/lib/chart-master/Chart.js')?>"></script>
	<script src="<?php echo base_url('assets/lib/chartjs-conf.js')?>"></script>

	<script src="<?php echo base_url('assets/lib/bubblechart.js') ?>"></script>
	<script type="text/javascript">
		bootbox.confirm({
			message: "This is a confirm with custom button text and color! Do you like it?",
			buttons: {
				confirm: {
					label: 'Yes',
					className: 'btn-success'
				},
				cancel: {
					label: 'No',
					className: 'btn-danger'
				}
			},
			callback: function (result) {
				console.log('This was logged in the callback: ' + result);
			}
		});
	</script>
	<script type="text/javascript">
    //mouse over navbar
    $('.navbar').mouseover(function(event) {
    	$(this).find('.navbar-tool').show();
    });

    //mouse out of navbar
    $('.navbar').mouseout(function(event) {
    	$(this).find('.navbar-tool').hide();
    });

    //on close collapse
    $('.collapse').on('hidden.bs.collapse', function () {
    	var target = '#'+$(this).attr('data-parent');
    	$(target).removeClass('collapse-open');
    });

    //on open collapse
    $('.collapse').on('shown.bs.collapse', function () {
    	var target = '#'+$(this).attr('data-parent');
    	$(target).addClass('collapse-open');
    })

</script>
</body>
</html>