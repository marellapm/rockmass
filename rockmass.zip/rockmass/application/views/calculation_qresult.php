
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<title>Detail Data</title>

	<!-- Favicons -->
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="icon">
	<link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<!--external css-->
	<link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
	<!-- Custom styles for this template -->
	<link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">
	
</head>

<body>

	<section id="container">
		<!--header start-->
		<header class="header black-bg">
			<div class="sidebar-toggle-box">
				<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>
			<!--logo start-->
			<a href="index.html" class="logo"><b>ROCK<span>MASS</span></b></a>
			<!--logo end-->
			<div class="top-menu">
				<ul class="nav pull-right top-menu">
					<li><a class="logout" href="<?php echo site_url('Login/logout') ?>">Logout</a></li>
				</ul>
			</div>
		</header>
		<!--header end-->
		\
		<!--sidebar start-->
		<aside>
			<div id="sidebar" class="nav-collapse ">
				<!-- sidebar menu start-->
				<ul class="sidebar-menu" id="nav-accordion">
					<p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/img/employee/'.$pict)?>" class="img-circle" width="80"></a></p>
					<h5 class="centered"><?php echo $nama ?></h5>
					<li class="mt">
						<a href="<?php echo site_url('Home')?>">
							<i class="fa fa-dashboard"></i>
							<span>Home</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('Show/view_data')?>">
							<i class="fa fa-th"></i>
							<span>Data</span>
						</a>
					</li>

					<li class="sub-menu">
						<a class="active" href="<?php echo site_url('Home/calculation_form')?>">
							<i class="fa fa-calculator"></i>
							<span>Calculation</span>
						</a>
					</li>

					<li class="sub-menu">
						<a href="<?php echo site_url('User/show_profil')?>">
							<i class="fa fa-cog"></i>
							<span>Profil</span>
						</a>
					</li>
				</ul>
				<!-- sidebar menu end-->
			</div>
		</aside>

		<section id="main-content">
			<section class="wrapper">
				<h3><i class="fa fa-angle-right"></i> Q Result</h3>
				<h4>Location : <?php echo "$location"; ?></h4>
				<div class="panel panel-default text-center">
					<div class="panel-heading">DETAIL INPUT</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">RQD</p>
								<p><h3><?php echo $rqd ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Set Number</p>
								<p><h3><?php echo $jn ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Joint Roughness Number</p>
								<p><h3><?php echo $jr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6" >
								<p class="medium mt">Joint Alteration Number</p>
								<p><h3><?php echo $ja ?></h3></p>
							</div>
						</div>

						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Joint Water Reduction</p>
								<p><h3><?php echo $jw ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Stress Reduction Factor</p>
								<p><h3><?php echo $srf ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">ESR</p>
								<p><h3><?php echo $esr ?></h3></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt">Lebar Galian (m)</p>
								<p><h3><?php echo $b ?></h3></p>
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-default text-center">
					<div class="panel-heading">Q Result</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-3 col-xs-6">
								<p class="medium mt"><h2>Q-Result</h2></p>
								<p><h4><?php echo number_format($qresult,3) ?></h4></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt"><h3>Q-Classification</h3></p>
								<p><h4><?php echo $q_classification ?></h4></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt"><h2>Q-Area</h2></p>
								<p><h4><?php echo $area ?></h4></p>
							</div>
							<div class="col-md-3 col-xs-6">
								<p class="medium mt"><h2>Notes</h2></p>
								<p><h4><?php echo $notes ?></h4></p>
							</div>
						</div>
						<br><br>
						<div class="row">
							<div class="col-md-2 col-xs-6">
								<p class="medium mt">Equivalent Dimension<br>(ED)</p>
								<p><h3><?php echo $ed ?></h3></p>
							</div>
							<div class="col-md-2 col-xs-6">
								<p class="medium mt">Rockbolt<br>(L)</p>
								<p><h3><?php echo $l ?></h3></p>
							</div>
							<div class="col-md-2 col-xs-6">
								<p class="medium mt">P roof<br><br></p>
								<p><h3><?php echo number_format($proof,3) ?></h3></p>
							</div>
							<div class="col-md-2 col-xs-6" >
								<p class="medium mt">Conditional A<br>(RQD/Jn)</p>
								<p><h3><?php echo number_format($conditional_a,3) ?></h3></p>
							</div>
							<div class="col-md-2 col-xs-6" >
								<p class="medium mt">Conditional B<br>(Jr/Ja)</p>
								<p><h3><?php echo number_format($conditional_b,3) ?></h3></p>
							</div>
							<div class="col-md-2 col-xs-6" >
								<p class="medium mt">Max Span<br>(unsupported)</p>
								<p><h3><?php echo number_format($spanmax,3) ?></h3></p>
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-default text-center">
					<div class="panel-heading">Q Table Result</div>
					<div class="panel-body">
						<?php if($area!=NULL) { $no=1;?>
							<table class="table">
								<tr>
									<td>No</td>
									<td>Area</td>
									<td>Q Value</td>
									<td>RQD/Jn</td>
									<td><?php if ($area<=16) {echo "Jr/Jn";} else {echo "Jr/Ja";} ?></td>
									<td>Span/ESR</td>
									<td>Type Of Support</td>
									<td>Notes</td>
								</tr>
								<?php foreach ($table as $table) { ?>
									<tr>
										<td><?php echo $no; ?></td>
										<td><?php echo $area; ?></td>
										<td><?php echo $qresult; ?></td>
										<td><?php echo $table->conditional_a; ?></td>
										<td><?php echo $table->conditional_b; ?></td>
										<td><?php echo $table->span_esr; ?></td>
										<td><?php echo $table->type_of_support; ?></td>
										<td><?php echo $table->notes; ?></td>
									</tr>
									<?php $no++; } ?>
							</table>
							<h4 align="left">Notes<br></h4>
								<h5 align="left">
									(sb)	: Spot Bolting <br>
									(B)		: Systematic Bolting (m) <br>
									(utg)	: Untensioned, Grounted <br>
									(tg)	: Tensioned <br>
									(S)		: Shotcrete (cm) <br>
									(mr)	: Mesh-reinforced <br>
									(clm)	: Chain-link Mesh <br>
									(CCA)	: Cast Concrete arch (cm) <br>
									(sr)	: Steel-reinforced <br>
								</h5>
							<?php } ?>
						</div>
					</div>

					<?php echo form_open('Calculation/calculate_rmr'); ?>
					<div class="panel panel-default text-center">
						<div class="panel-heading">Select RMR</div>
						<div class="panel-body">
							<form class="form-horizontal style-form">
								<input type="hidden" name="id" value="<?php echo $id ?>">
								<input type="hidden" name="rqd" value="<?php echo $rqd ?>">
								<input type="hidden" name="jn" value="<?php echo $jn ?>">
								<input type="hidden" name="jr" value="<?php echo $jr ?>">
								<input type="hidden" name="ja" value="<?php echo $ja ?>">
								<input type="hidden" name="jw" value="<?php echo $jw ?>">
								<input type="hidden" name="srf" value="<?php echo $srf ?>">
								<input type="hidden" name="esr" value="<?php echo $esr ?>">
								<input type="hidden" name="b" value="<?php echo $b ?>">
								<input type="hidden" name="ed" value="<?php echo $ed ?>">
								<input type="hidden" name="q" value="<?php echo $qresult ?>">
								<input type="hidden" name="p_roof" value="<?php echo $proof ?>">
								<input type="hidden" name="cond_a" value="<?php echo $conditional_a ?>">
								<input type="hidden" name="cond_b" value="<?php echo $conditional_b ?>">
								<input type="hidden" name="kode" value="<?php echo $table_result ?>">
								<input type="hidden" name="support_type_result" value="<?php echo $support_type ?>">
								<input type="hidden" name="qarea" value="<?php echo $area ?>">
								<input type="hidden" name="notes" value="<?php echo $notes ?>">
								<input type="hidden" name="q_classification" value="<?php echo $q_classification ?>">
								<input type="hidden" name="location" value="<?php echo $location ?>">
								<input type="hidden" name="l" value="<?php echo $l ?>">
								<input type="hidden" name="spanmax" value="<?php echo $spanmax ?>">
								<input type="hidden" name="q_table" value="<?php echo $q_table ?>">

								<div class="form-group">
									<label for="sel1"> Select RMR :</label>
									<select class="form-control" id="sel1" name="rmrtype">
										<option value="bienawski">Bienawski,1976</option>
										<option value="cameron">Cameron, 1981</option>
										<option value="rutledge">Rutledge & Preston, 1978</option>
										<option value="abad">Abad, 1984</option>
										<option value="moreno">Moreno, 1980</option>
									</select>
								</div>
								<div id="success"></div>
								<div class="form-group">
									<div class="col-lg-offset-1 col-lg-10">
										<button class="btn btn-theme" type="submit">Done</button>
									</div>
								</div>
							</form>
						</div>
					</div>
					<?php echo form_close(); ?>

				</section>
			</section>
		</section>

		<!-- js placed at the end of the document so the pages load faster -->
		<script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
		<script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
		<script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
		<script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
		<script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
		<!--common script for all pages-->
		<script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
		<!--script for this page-->
		<script src="<?php echo base_url('assets/lib/chart-master/Chart.js')?>"></script>
		<script src="<?php echo base_url('assets/lib/chartjs-conf.js')?>"></script>

		<script src="<?php echo base_url('assets/lib/bubblechart.js') ?>"></script>
	</body>
	</html>