<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Login</title>

  <!-- Favicons -->
  <link href="<?php echo base_url('assets/img/logo.png" rel="icon')?>">
  <link href="<?php echo base_url('assets/img/logo.png')?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url('assets/lib/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url('assets/lib/font-awesome/css/font-awesome.css')?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-fileupload/bootstrap-fileupload.css')?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-datepicker/css/datepicker.css')?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-daterangepicker/daterangepicker.css')?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-timepicker/compiled/timepicker.css')?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/lib/bootstrap-datetimepicker/datertimepicker.css')?>" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/style-responsive.css')?>" rel="stylesheet">


  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
    ======================================================= -->
  </head>

  <body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

      <div class="container">
        <section class="form-panel">
          <h3><i class="fa fa-angle-right"></i> Create Account </h3>
          <form class="form-horizontal style-form" method="POST" action="<?php echo site_url('User/save_data') ?>">
            <div class="form-group" id="collapse-rqd" data-toggle="collapse" href="#collapserqd">
              <label class="col-sm-3 col-sm-3 control-label">Name</label>
              <div class="col-sm-9">
                <input type="text" name="name" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3">Birth</label>
              <div class="col-md-3 col-xs-11">
                <div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="01-01-2014" class="input-append date dpYears">
                  <input type="text" readonly="" value="01-01-2014" size="16" class="form-control">
                  <span class="input-group-btn add-on">
                    <button class="btn btn-theme" type="button"><i class="fa fa-calendar" required></i></button>
                  </span>
                </div>
                <span class="help-block">Select date</span>
              </div>
            </div>

            <div class="form-group" id="collapse-rqd" data-toggle="collapse" href="#collapserqd">
              <label class="col-sm-3 col-sm-3 control-label">Employee Number</label>
              <div class="col-sm-9">
                <input type="text" name="employee_number" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Position</label>
              <div class="col-sm-9">
                <input type="text" name="position" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">E-mail</label>
              <div class="col-sm-9">
                <input type="email" name="email" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Address</label>
              <div class="col-sm-9">
                <textarea name="address" class="form-control round-form" required> </textarea>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Phone/Fax</label>
              <div class="col-sm-9">
                <input type="text" name="phone" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Username</label>
              <div class="col-sm-9">
                <input type="text" name="username" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Password</label>
              <div class="col-sm-9">
                <input type="text" name="password" class="form-control round-form" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 col-sm-3 control-label">Picture</label>
              <div class="col-lg-6">
                <input type="file" name="picture" class="default">
              </div>
            </div>

            <div class="form-group">
              <div class="col-lg-offset-5 col-lg-10">
                <button class="btn btn-theme" type="submit">Create an Account</button>
                <button class="btn btn-theme04" type="reset">Cancel</button> <br>
                <a class="" href="<?php echo site_url('Login') ?>">
                  Back to login page
                </a>
              </div>
            </form>
          </section>
        </div>

        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo base_url('assets/lib/jquery/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/lib/bootstrap/js/bootstrap.min.js')?>"></script>
        <script class="include" type="text/javascript" src="<?php echo base_url('assets/lib/jquery.dcjqaccordion.2.7.js')?>"></script>
        <script src="<?php echo base_url('assets/lib/jquery.scrollTo.min.js')?>"></script>
        <script src="<?php echo base_url('assets/lib/jquery.nicescroll.js')?>" type="text/javascript"></script>
        <!--common script for all pages-->
        <script src="<?php echo base_url('assets/lib/common-scripts.js')?>"></script>
        <!--script for this page-->
        <script src="<?php echo base_url('assets/lib/jquery-ui-1.9.2.custom.min.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-fileupload/bootstrap-fileupload.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-datepicker/js/bootstrap-datepicker.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-daterangepicker/date.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-daterangepicker/daterangepicker.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-daterangepicker/moment.min.js')?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/lib/bootstrap-timepicker/js/bootstrap-timepicker.js')?>"></script>
        <script src="<?php echo base_url('assets/lib/advanced-form-components.js')?>"></script>

      </body>

      </html>
