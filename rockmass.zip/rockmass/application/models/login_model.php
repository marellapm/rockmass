<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login_model extends CI_MODEL {

	/**
	 * Class Constructor
	 */
	function __construct()
	{
		$this->load->database();
	}
	
	/**
	 * Method to validate login data
	 * @param  string $username Username admin
	 * @param  string $password Password admin
	 * @return boolean          Valid or not valid login admin
	 */
	public function validate_login($username, $password)
	{
		$query = $this->db->get_where('employee', array('username' => $username, 'password' => $password));
		if ($query->num_rows() > 0) 
		{
			return $query->first_row();
		} else return NULL;
	}
}
