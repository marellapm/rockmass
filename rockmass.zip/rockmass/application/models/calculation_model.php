<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class calculation_model extends CI_MODEL {

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_qtable($area) {

		$query = $this->db->get_where('q_system', array('support_category' => $area));
		return $query->result();
	}

	public function input_data($data) {
		$query = $this->db->insert('data', $data);

		if ($query>0) {
			return "Berhasil";
		} else {
			return "Gagal";
		}
	}

	public function get_support_type($area,$kode) {
		$query = $this->db->get_where('q_system', array('support_category' => $area, 'kode' => $kode));
		return $query->row();
	}

	public function get_detail($id) {
		$query = $this->db->get_where('result', array('id' => $id));
		return $query->row();
	}

	public function delete_data($id) {
		$this->db->where('id', $id);
		$this->db->delete('data');
	}

	public function get_data() {
		return $this->db->get('data');
	}

	public function get_rmr($rmr_class) {
		$query = $this->db->get_where('rmr', array('rmr_class' => $rmr_class));
		return $query->row();
	}

	public function get_rqd() {
		$query = $this->db->get('rqd_table');
		return $query->result();
	}

	public function get_jn() {
		$query = $this->db->get('jn_table');
		return $query->result();
	}

	public function get_jr() {
		$query = $this->db->get('jr_table');
		return $query->result();
	}

	public function get_ja() {
		$query = $this->db->get('ja_table');
		return $query->result();
	}

	public function get_jw() {
		$query = $this->db->get('jw_table');
		return $query->result();
	}

	public function get_srf() {
		$query = $this->db->get('srf_table');
		return $query->result();
	}

	public function get_esr() {
		$query = $this->db->get('esr_table');
		return $query->result();
	}

	public function edit_data($id,$update) {
		$this->db->where('id', $id);
		$this->db->update('data', $update);
	}

	public function get_notes($note) {
		$query = $this->db->get_where('q_notes', array('notes_number' => $note));
		return $query->row();
	}
}
