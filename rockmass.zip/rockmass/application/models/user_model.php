<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user_model extends CI_MODEL {

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_user($username) {

		$query = $this->db->get_where('employee', array('username' => $username));
		return $query->row();
	}

	public function get_user_id($id) {

		$query = $this->db->get_where('employee', array('id' => $id));
		return $query->row();
	}

	public function edit_data($username,$data) {
		$this->db->where('username', $username);
		$this->db->update('employee', $data);
	}

	public function input_data($data) {
		$query = $this->db->insert('employee', $data);
		if ($query>0) {
			return "Berhasil";
		} else {
			return "Gagal";
		}
	}

	public function get_all_user() {
		$query = $this->db->get('employee');
		return $query->result();
	}

}
