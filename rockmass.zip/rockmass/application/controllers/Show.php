<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Show extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('html', 'form', 'url_helper'));
		$this->load->model('login_model');
		$this->load->model('calculation_model');
		$this->load->library('session');
		define("e","2.7182818284");

		if($this->session->userdata('status') != "login"){
			redirect('Login');
		}
	}

	public function index()
	{
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		$this->load->view('home', $data);
	}

	public function view_data() {
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');

		$data['hasil'] = $this->calculation_model->get_data()->result();
		$this->load->view('tampil_data', $data);
	}

	public function view_detail() {
		$id = $this->input->get('id');
		$data['detail'] = $this->calculation_model->get_detail($id);
		
		$data['table'] = $this->calculation_model->get_data()->result();
		//var_dump($data['table']);

		$data['q'] = $data['detail']->qresult;
		if (($data['q']>=0.001) and ($data['q']<0.01)) {
			$data['q_classification'] = "Exceptionally Poor";
		} else if (($data['q']>=0.01) and ($data['q']<0.1)) {
			$data['q_classification'] = "Extremely Poor";
		} else if (($data['q']>=0.1) and ($data['q']<1)) {
			$data['q_classification'] = "Very Poor";
		} else if (($data['q']>=1) and ($data['q']<4)) {
			$data['q_classification'] = "Poor";
		} else if (($data['q']>=4) and ($data['q']<10)) {
			$data['q_classification'] = "Fair";
		} else if (($data['q']>=10) and ($data['q']<40)) {
			$data['q_classification'] = "Good";
		} else if (($data['q']>=40) and ($data['q']<100)) {
			$data['q_classification'] = "Very Good";
		} else if (($data['q']>=100) and ($data['q']<400)) {
			$data['q_classification'] = "Extremely Good";
		} else if (($data['q']>=400) and ($data['q']<1000)) {
			$data['q_classification'] = "Exceptionally Good";
		}

		//NOTES
		$data['notes'] = $data['detail']->notes;
		if((($data['notes'])=="No notes") or ($data['notes']==NULL)) {
			$data['notes_table'][0] = new stdClass();
			$data['notes_table'][0]->notes = "No notes";
			$data['notes_table'][0]->notes_number = 0;
		} else {
			$notes = $data['notes'];
			$note_pars = explode(",", $notes);
			$i=0;
			foreach ($note_pars as $note) {
				$data['notes_table'][$i] = $this->calculation_model->get_notes($note);
				$i++;
			}
		}

		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		//var_dump($data);
		$this->load->view("detail", $data);

	}

	public function view_detaill() {
		$id = $this->input->get('id');
		$detail = $this->calculation_model->get_detail($id);
		//var_dump($detail->rqd);

		$data = $this->calculation_model->get_data();

		$data = array(
			'id' => $detail->id,
			'rqd' => $detail->rqd,
			'jn' => $detail->jn,
			'jr' => $detail->jr,
			'ja' => $detail->ja,
			'jw' => $detail->jw,
			'srf' => $detail->srf,
			'esr' => $detail->esr,
			'span' => $detail->span,
			'ed' => $detail->ed,
			'qarea' => $detail->qarea,
			'p_roof' => $detail->p_roof,
			'q' => $detail->qresult,
			'cond_a' => $detail->cond_a,
			'cond_b' => $detail->cond_b,
			'kode' => $detail->kode,
			'support_type_result' => $detail->support_type_result,
			'notes' => $detail->notes,
			'location' => $detail->location,
			'rmr_type' => $detail->rmr_type,
			'rmr' => $detail->rmr_value,
			'rmr_class' => $detail->rmr_class,
			'l' => $detail->l,
			'spanmax' => $detail->spanmax
		);

		//MENGHITUNG PRoof
		if ($data['jn']<3) {
			$data['proof']=((2/3)*(pow($data['jn'],(1/2)))*(pow($data['jr'],(-1)))*(pow($data['q'],(-1/3))));
		} else {
			$data['proof']=((2/$data['jr'])*(pow($data['q'],(-1/3))));
		}

		//MENGHITUNG CONDITIONAL FACTOR
		//RQD/Jn
		$conditional_a=($data['rqd']/$data['jn']);
		$data['conditional_a']=$conditional_a;
		//Jr/Jn
		$conditional_b=($data['jr']/$data['jn']);
		$data['conditional_b']=$conditional_b;

		if (($data['q']>=0.001) and ($data['q']<0.01)) {
			$data['q_classification'] = "Exceptionally Poor";
		} else if (($data['q']>=0.01) and ($data['q']<0.1)) {
			$data['q_classification'] = "Extremely Poor";
		} else if (($data['q']>=0.1) and ($data['q']<1)) {
			$data['q_classification'] = "Very Poor";
		} else if (($data['q']>=1) and ($data['q']<4)) {
			$data['q_classification'] = "Poor";
		} else if (($data['q']>=4) and ($data['q']<10)) {
			$data['q_classification'] = "Fair";
		} else if (($data['q']>=10) and ($data['q']<40)) {
			$data['q_classification'] = "Good";
		} else if (($data['q']>=40) and ($data['q']<100)) {
			$data['q_classification'] = "Very Good";
		} else if (($data['q']>=100) and ($data['q']<400)) {
			$data['q_classification'] = "Extremely Good";
		} else if (($data['q']>=400) and ($data['q']<1000)) {
			$data['q_classification'] = "Exceptionally Good";
		}

		$rmr = $data['rmr'];
		if(($rmr <= 100) and ($rmr > 80)) {
			$rmrclass="I";
		} else if(($rmr <= 80) and ($rmr > 60)) {
			$rmrclass="II";
		} else if(($rmr <= 60) and ($rmr > 40)) {
			$rmrclass = "III";
		} else if (($rmr <= 40) and ($rmr > 20)) {
			$rmrclass = "IV";
		} else if (($rmr <=20) and ($rmr >0)) {
			$rmrclass = "V";
		} else {
			$rmrclass = "0";
		}
		

		if((($data['notes'])=="No notes") or ($data['notes']==NULL)) {
			$data['notes_table'][0] = new stdClass();
			$data['notes_table'][0]->notes = "No notes";
			$data['notes_table'][0]->notes_number = 0;
		} else {
			$notes = $data['notes'];
			$note_pars = explode(",", $notes);
			$i=0;
			foreach ($note_pars as $note) {
				$data['notes_table'][$i] = $this->calculation_model->get_notes($note);
				$i++;
			}
		}

		if($rmrclass == "0") {
			$data['rmr_table'] = new stdClass();
			$data['rmr_table']->rmr_class = 0;
			$data['rmr_table']->rmr_value = 0;
			$data['rmr_table']->rmr_classification = 0;
			$data['rmr_table']->avg_stand = 0;
			$data['rmr_table']->cohession = 0;
			$data['rmr_table']->angle = 0;
			$data['rmr_table']->bearing_pressure = 0;
			$data['rmr_table']->cut_slope = 0;
			$data['rmr_type']=0;
		} else {
			$data['rmr_table'] = $this->calculation_model->get_rmr("$rmrclass");
		}	
		
		$data['table'] = $this->calculation_model->get_data()->result();
		//var_dump($data['table']);
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		//var_dump($data);
		$this->load->view("detail", $data);
	}

}
?>