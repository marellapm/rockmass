<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calculation extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form');
		$this->load->model('calculation_model');
		define("e","2.7182818284");
		$this->load->library('session');

		if($this->session->userdata('status') != "login"){
			redirect('Login');
		}
	}

	public function index() {
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		$this->load->view('home', $data);
	}

	public function home() {
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');

		$this->load->view('header_admin');
		$this->load->view('home_admin');
		$this->load->view('footer_admin.php');
	}


	// PERHITUNGAN Q-SYSTEM
	public function calculate() {
		$area=0;
		$data = array(
			'id' => $this->input->post('id'),
			'rqd' => $this->input->post('rqd'),
			'jn' => $this->input->post('jn'),
			'jr' => $this->input->post('jr'),
			'ja' => $this->input->post('ja'),
			'jw' => $this->input->post('jw'),
			'srf' => $this->input->post('srf'),
			'esr' => $this->input->post('esr'),
			'b' => $this->input->post('b'),
			'location' => $this->input->post('location')
		);

		//MENGHITUNG NILAI L
		$data['l'] = ((2+(0.15*$data['b']))/$data['esr']);

		//MENGHITUNG NILAI Q
		$data['qresult']=(($data['rqd']/$data['jn'])*($data['jr']/$data['ja'])*($data['jw']/$data['srf']));

		//MENGHITUNG SPAN MAKSIMUM
		$data['spanmax'] = (2*$data['esr'])*(pow($data['qresult'],0.4));

		//MENGHITUNG NILAI ED
		$ed=($data['b']/$data['esr']);

		//MENGHITUNG PRoof
		if ($data['jn']<3) {
			$data['proof']=((2/3)*(pow($data['jn'],(1/2)))*(pow($data['jr'],(-1)))*(pow($data['qresult'],(-1/3))));
		} else {
			$data['proof']=((2/$data['jr'])*(pow($data['qresult'],(-1/3))));
		}

		//KLASIFKASI AREA
		//EXC GOOD
		if (($data['qresult']<=1000) and ($data['qresult']>=400)) {
			$dx=(1000-400);
			$y=$ed;
			$x=$data['qresult'];
			$marea1bawah=(30-20)/$dx;
			$marea2bawah=(40-30)/$dx;
			$marea3bawah=(60-46)/$dx;
			$marea4bawah=(80-65)/$dx;
			$marea4atas=(100-88)/$dx;

			//mencari batas titik y
			$y1=30-($marea1bawah*(1000-$x));
			$y2=40-($marea2bawah*(1000-$x));
			$y3=60-($marea3bawah*(1000-$x));
			$y4=80-($marea4bawah*(1000-$x));
			$y4a=100-($marea4atas*(1000-$x));

			//pebandingan
			if ($y>=$y1 and $y<$y2) {
				$area=1;
			}
			else if ($y>=$y2 and $y<$y3) {
				$area=2;
			}
			else if ($y>=$y3 and $y<$y4) {
				$area=3;
			}
			else if ($y>=$y4 and $y<$y4a) {
				$area=4;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Excavation Good";
		}

		//EXT GOOD
		else if (($data['qresult']<=400) and ($data['qresult']>=100)) {
			$dx=(400-100);
			$y=$ed;
			$x=$data['qresult'];
			$marea5bawah=(20-12)/$dx;
			$marea6bawah=(30-19)/$dx;
			$marea7bawah=(45-30)/$dx;
			$marea8bawah=(65-48)/$dx;
			$marea8atas=(88-72)/$dx;

			//mencari batas titik y
			$y5=20-($marea5bawah*(400-$x));
			$y6=30-($marea6bawah*(400-$x));
			$y7=45-($marea7bawah*(400-$x));
			$y8=65-($marea8bawah*(400-$x));
			$y8a=88-($marea8atas*(400-$x));

			//pebandingan
			if ($y>=$y5 and $y<$y6) {
				$area=5;
			}
			else if ($y>=$y6 and $y<$y7) {
				$area=6;
			}
			else if ($y>=$y7 and $y<$y8) {
				$area=7;
			}
			else if ($y>=$y8 and $y<$y8a) {
				$area=8;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Extremely Good";
		}

		//VERY GOOD
		else if (($data['qresult']<=100) and ($data['qresult']>=40)) {
			$dx=(100-40);
			$y=$ed;
			$x=$data['qresult'];
			$marea9bawah=(12-8.5)/$dx;
			$marea10bawah=(19-14)/$dx;
			$marea11bawah=(30-23)/$dx;
			$marea12bawah=(48-40)/$dx;
			$marea12atas=(72-65)/$dx;

			//mencari batas titik y
			$y9=12-($marea9bawah*(100-$x));
			$y10=19-($marea10bawah*(100-$x));
			$y11=30-($marea11bawah*(100-$x));
			$y12=48-($marea12bawah*(100-$x));
			$y12a=72-($marea12atas*(100-$x));

			//pebandingan
			if ($y>=$y9 and $y<$y10) {
				$area=9;
			}
			else if ($y>=$y10 and $y<$y11) {
				$area=10;
			}
			else if ($y>=$y11 and $y<$y12) {
				$area=11;
			}
			else if ($y>=$y12 and $y<$y12a) {
				$area=12;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Very Good";
		}

		//GOOD
		else if (($data['qresult']<=40) and ($data['qresult']>=10)) {
			$dx=(40-10);
			$y=$ed;
			$x=$data['qresult'];
			$marea13bawah=(8.5-5)/$dx;
			$marea14bawah=(14-9)/$dx;
			$marea15bawah=(23-15)/$dx;
			$marea16bawah=(40-30)/$dx;
			$marea16atas=(65-52)/$dx;

			//mencari batas titik y
			$y13=8.5-($marea13bawah*(40-$x));
			$y14=14-($marea14bawah*(40-$x));
			$y15=23-($marea15bawah*(40-$x));
			$y16=40-($marea16bawah*(40-$x));
			$y16a=65-($marea16atas*(40-$x));

			//pebandingan
			if ($y>=$y13 and $y<$y14) {
				$area=13;
			}
			else if ($y>=$y14 and $y<$y15) {
				$area=14;
			}
			else if ($y>=$y15 and $y<$y16) {
				$area=15;
			}
			else if ($y>=$y16 and $y<$y16a) {
				$area=16;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Good";
		}

		//FAIR
		else if (($data['qresult']<=10) and ($data['qresult']>=4)) {
			$dx=(10-4);
			$y=$ed;
			$x=$data['qresult'];
			$marea17bawah=(5-3.5)/$dx;
			$marea18bawah=(9-7)/$dx;
			$marea19bawah=(15-12)/$dx;
			$marea20bawah=(29-24)/$dx;
			$marea20atas=(52-46)/$dx;

			//mencari batas titik y
			$y17=5-($marea17bawah*(10-$x));
			$y18=9-($marea18bawah*(10-$x));
			$y19=15-($marea19bawah*(10-$x));
			$y20=29-($marea20bawah*(10-$x));
			$y20a=52-($marea20atas*(10-$x));

			//pebandingan
			if ($y>=$y17 and $y<$y18) {
				$area=17;
			}
			else if ($y>=$y18 and $y<$y19) {
				$area=18;
			}
			else if ($y>=$y19 and $y<$y20) {
				$area=19;
			}
			else if ($y>=$y20 and $y<$y20a) {
				$area=20;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Fair";
		}

		//POOR
		else if (($data['qresult']<=4) and ($data['qresult']>=1)) {
			$dx=(4-1);
			$y=$ed;
			$x=$data['qresult'];
			$marea21bawah=(3.5-2.1)/$dx;
			$marea22bawah=(6.5-4.5)/$dx;
			$marea23bawah=(11.5-8)/$dx;
			$marea24bawah=(24-18)/$dx;
			$marea24atas=(46-38)/$dx;

			//mencari batas titik y
			$y21=3.5-($marea21bawah*(4-$x));
			$y22=6.5-($marea22bawah*(4-$x));
			$y23=11.5-($marea23bawah*(4-$x));
			$y24=24-($marea24bawah*(4-$x));
			$y24a=46-($marea24atas*(4-$x));

			//pebandingan
			if ($y>=$y21 and $y<$y22) {
				$area=21;
			}
			else if ($y>=$y22 and $y<$y23) {
				$area=22;
			}
			else if ($y>=$y23 and $y<$y24) {
				$area=23;
			}
			else if ($y>=$y24 and $y<$y24a) {
				$area=24;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Poor";
		}

		//VERY POOR A
		else if (($data['qresult']<=1) and ($data['qresult']>=0.4)) {
			$dx=(1-0.4);
			$y=$ed;
			$x=$data['qresult'];
			$marea25bawah=(2.1-1.5)/$dx;
			$marea26bawah=(4.2-3.2)/$dx;
			$marea27bawah=(7.5-6)/$dx;
			$marea28bawah=(18-15)/$dx;
			$marea28atas=(38-34)/$dx;

			//mencari batas titik y
			$y25=2.1-($marea25bawah*(1-$x));
			$y26=4.2-($marea26bawah*(1-$x));
			$y27=7.5-($marea27bawah*(1-$x));
			$y28=18-($marea28bawah*(1-$x));
			$y28a=38-($marea28atas*(1-$x));

			//pebandingan
			if ($y>=$y25 and $y<$y26) {
				$area=25;
			}
			else if ($y>=$y26 and $y<$y27) {
				$area=26;
			}
			else if ($y>=$y27 and $y<$y28) {
				$area=27;
			}
			else if ($y>=$y28 and $y<$y28a) {
				$area=28;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Very Poor";
		}

		//VERY POOR B
		else if (($data['qresult']<=0.4) and ($data['qresult']>=0.1)) {
			$dx=(0.4-0.1);
			$y=$ed;
			$x=$data['qresult'];
			$marea29bawah=(1.5-1)/$dx;
			$marea30bawah=(3.1-2.2)/$dx;
			$marea31bawah=(6-4)/$dx;
			$marea32bawah=(14.5-11)/$dx;
			$marea32atas=(34-28)/$dx;

			//mencari batas titik y
			$y29=1.5-($marea29bawah*(0.4-$x));
			$y30=3.1-($marea30bawah*(0.4-$x));
			$y31=6-($marea31bawah*(0.4-$x));
			$y32=14.5-($marea32bawah*(0.4-$x));
			$y32a=34-($marea32atas*(0.4-$x));

			//pebandingan
			if ($y>=$y29 and $y<$y30) {
				$area=29;
			}
			else if ($y>=$y30 and $y<$y31) {
				$area=30;
			}
			else if ($y>=$y31 and $y<$y32) {
				$area=31;
			}
			else if ($y>=$y32 and $y<$y32a) {
				$area=32;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Very Poor";
		}

		//EXT POOR
		else if (($data['qresult']<=0.1) and ($data['qresult']>=0.01)) {
			$dx=(0.1-0.01);
			$y=$ed;
			$x=$data['qresult'];
			$marea33bawah=0;
			$marea34bawah=(3.9-2)/$dx;
			$marea35bawah=(11-6.2)/$dx;
			$marea35atas=(28-20)/$dx;

			//mencari batas titik y
			$y33=1;
			$y34=3.9-($marea34bawah*(0.1-$x));
			$y35=11-($marea35bawah*(0.1-$x));
			$y35a=28-($marea35atas*(0.1-$x));

			//pebandingan
			if ($y>=$y33 and $y<$y34) {
				$area=33;
			}
			else if ($y>=$y34 and $y<$y35) {
				$area=34;
			}
			else if ($y>=$y35 and $y<$y35a) {
				$area=35;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Extremely Poor";
		}

		//EXC POOR
		else if (($data['qresult']<=0.01) and ($data['qresult']>=0.001)) {
			$dx=(0.01-0.001);
			$y=$ed;
			$x=$data['qresult'];
			$marea36bawah=0;
			$marea37bawah=(2-1)/$dx;
			$marea38bawah=(6.5-4)/$dx;
			$marea38atas=(20-15)/$dx;

			//mencari batas titik y
			$y36=1;
			$y37=2-($marea37bawah*(0.1-$x));
			$y38=6.5-($marea38bawah*(0.1-$x));
			$y38a=20-($marea38atas*(0.1-$x));

			//pebandingan
			if ($y>=$y36 and $y<$y37) {
				$area=36;
			}
			else if ($y>=$y37 and $y<$y38) {
				$area=37;
			}
			else if ($y>=$y38 and $y<$y38a) {
				$area=38;
			}
			else {
				$area=0;
			}
			$data['q_classification'] = "Excavation Poor";
		} else {
			$data['q_classification'] = "No Classification";
		}



		//MENGHITUNG CONDITIONAL FACTOR
		//RQD/Jn
		$conditional_a=($data['rqd']/$data['jn']);
		$data['conditional_a']=$conditional_a;

		if ($area<16) {
			//Jr/Ja
			$conditional_b=($data['jr']/$data['jn']);
		} else {
			//Jr/Ja
			$conditional_b=($data['jr']/$data['ja']);
		}		
		$data['conditional_b']=$conditional_b;

		$data['area']=$area;
		$data['ed']=$ed;

		$data['table_res'] = $this->condition($area,$conditional_a,$conditional_b,$ed);
		//var_dump($data['table_result']);
		$data['table_result'] = $data['table_res'][0];
		$i=0;
		if ($area!=NULL) {
			foreach ($data['table_res'] as $table_result) {
				if ($table_result==1) {
					$kode = 'a';
				} else if ($table_result==2) {
					$kode = 'b';
				} else if ($table_result==3) {
					$kode = 'c';
				} else if ($table_result==4) {
					$kode = 'd';
				} else if ($table_result==5) {
					$kode = 'e';
				}
				$data['table'][$i] = $this->calculation_model->get_support_type($area,$kode);
				$i++;
			}
		}
		

		//MENGAMBIL DATA SUPPORT TYPE DAN NOTES
		if ($area != NULL) {
			$row = $this->calculation_model->get_support_type($area,$kode);
			
			$data['support_type'] = $row->type_of_support;
			$data['q_table'] = $row->id_q;
			$notes = $row->notes;
			if($notes==NULL) {
				$data['note'] = "No Notes";
				$data['notes']=0;
			} else {
				$data['notes'] = $notes;
			}
			//var_dump($data['support_type']);
			//var_dump($data['notes']);
			//var_dump($data['area']);
		} else {
			$data['support_type'] = 0;
			$data['notes'] = 0;
			$data['q_table'] = 0;
			$data['row'] = 0;
		}
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		
		$this->load->view("calculation_qresult", $data);
		
	}

	//MENCOCOKKAN NILAI TABEL Q-SYSTEM
	public function condition($area,$conditional_a,$conditional_b,$ed) {
		$area=$area;
		$data['conditional_a']=$conditional_a;
		$data['conditional_b']=$conditional_b;
		$data['conditional_c']=$ed;
		$tipes=$this->calculation_model->get_qtable($area);

		$arr = 1;
		$a=NULL;
		$n=0;
		foreach ($tipes as $tipe) {
			//CEK KONDISIONAL
			$cond_a=$tipe->conditional_a;
			$cond_b=$tipe->conditional_b;
			$cond_c=$tipe->span;


			$cond_a_pars = explode(" ", $cond_a);
			$cond_b_pars = explode(" ", $cond_b);
			$cond_c_pars = explode(" ", $cond_c);

			//var_dump($arr);
			//echo "<br>Cond A Pars =";
			//var_dump($cond_a_pars); echo "<br>";
			//echo "Cond B Pars =";
			//var_dump($cond_b_pars); echo "<br>";
			//echo "Cond C Pars =";
			//var_dump($cond_c_pars); echo "<br>";

			$c=false;
			//KONDISI A TIDAK NULL
			if($cond_a != NULL) {
				if ($cond_a_pars[0] == '>') {
					if($data['conditional_a'] > $cond_a_pars[1]) {
						
						if($cond_b != NULL) {
							if($cond_b_pars[0] == '>') {
								if($data['conditional_b'] > $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '>=') {
								if($data['conditional_b'] >= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<') {
								if($data['conditional_b'] < $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<=') {
								if($data['conditional_b'] <= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						if($cond_c != NULL) {
							if($cond_c_pars[0] == '>') {
								if($data['conditional_c'] > $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '>=') {
								if($data['conditional_c'] >= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<') {
								if($data['conditional_c'] < $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<=') {
								if($data['conditional_c'] <= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						//KONDISI A TIDAK NULL
						if ($cond_b == NULL and $cond_c == NULL) {
							$a=$arr;
							$c = true;
						}
					}
				}
				else if ($cond_a_pars[0] == '>=') {
					if($data['conditional_a'] >= $cond_a_pars[1]) {
						
						if($cond_b != NULL) {
							if($cond_b_pars[0] == '>') {
								if($data['conditional_b'] > $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '>=') {
								if($data['conditional_b'] >= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<') {
								if($data['conditional_b'] < $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<=') {
								if($data['conditional_b'] <= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						if($cond_c != NULL) {
							if($cond_c_pars[0] == '>') {
								if($data['conditional_c'] > $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '>=') {
								if($data['conditional_c'] >= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<') {
								if($data['conditional_c'] < $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<=') {
								if($data['conditional_c'] <= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						//KONDISI A TIDAK NULL
						if ($cond_b == NULL and $cond_c == NULL) {
							$a=$arr;
							$c = true;
						}
					}
				}
				else if ($cond_a_pars[0] == '<') {
					//var_dump("aaa");
					if($data['conditional_a'] < $cond_a_pars[1]) {
						
						if($cond_b != NULL) {
							if($cond_b_pars[0] == '>') {
								if($data['conditional_b'] > $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '>=') {
								if($data['conditional_b'] >= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<') {
								//var_dump(expression);
								if($data['conditional_b'] < $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<=') {
								if($data['conditional_b'] <= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						if($cond_c != NULL) {
							if($cond_c_pars[0] == '>') {
								if($data['conditional_c'] > $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '>=') {
								if($data['conditional_c'] >= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<') {
								if($data['conditional_c'] < $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<=') {
								if($data['conditional_c'] <= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						//KONDISI A TIDAK NULL
						if ($cond_b == NULL and $cond_c == NULL) {
							$a=$arr;
							$c = true;
						}
					}
				}
				else if ($cond_a_pars[0] == '<=') {
					//var_dump("aaaaa");
					if($data['conditional_a'] <= $cond_a_pars[1]) {
						
						if($cond_b != NULL) {
							if($cond_b_pars[0] == '>') {
								if($data['conditional_b'] > $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '>=') {
								if($data['conditional_b'] >= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<') {
								if($data['conditional_b'] < $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_b_pars[0] == '<=') {
								if($data['conditional_b'] <= $cond_b_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						if($cond_c != NULL) {
							//var_dump("bbbbb");
							//var_dump($cond_c_pars[0]);
							if($cond_c_pars[0] == '>') {
								if($data['conditional_c'] > $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '>=') {
								if($data['conditional_c'] >= $cond_c_pars[1]) {
								//var_dump("ccccc");
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<') {
								if($data['conditional_c'] < $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}

							if($cond_c_pars[0] == '<=') {
								if($data['conditional_c'] <= $cond_c_pars[1]) {
									$a = $arr;
									$c = true;
								}
							}
						}

						//KONDISI A TIDAK NULL
						if ($cond_b == NULL and $cond_c == NULL) {
							$a=$arr;
							$c = true;
						}
					}
				}
			}

			//KONDISI A NULL KONDISI B TIDAK NULL
			else if($cond_b != NULL) {
				if($cond_b_pars[0] == '>') {
					if($data['conditional_b'] > $cond_b_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_b_pars[0] == '>=') {
					if($data['conditional_b'] >= $cond_b_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_b_pars[0] == '<') {
					if($data['conditional_b'] < $cond_b_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_b_pars[0] == '<=') {
					if($data['conditional_b'] <= $cond_b_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}
			}

			//KONDISI A NULL B NULL DAN C TIDAK NULL
			else if($cond_c != NULL) {
				if($cond_c_pars[0] == '>') {
					if($data['conditional_c'] > $cond_c_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_c_pars[0] == '>=') {
					if($data['conditional_c'] >= $cond_c_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_c_pars[0] == '<') {
					if($data['conditional_c'] < $cond_c_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}

				if($cond_c_pars[0] == '<=') {
					if($data['conditional_c'] <= $cond_c_pars[1]) {
						$a = $arr;
						$c = true;
					}
				}
			}

			else if($cond_a==NULL and $cond_b==NULL and $cond_c==NULL){
				$a = $arr;
				$c = true;
			}

			$arr++;
			if($a!=NULL and $c==true) {
				//echo "a = "; var_dump($a);
				$b[$n]=$a;
				$n++;
			}
		//endforeach
		}
		if ($area != 0) {return $b;}
		else { return 0; }
	}

	function calculate_rmr(){

		$data = array(
			'id' => $this->input->post('id'),
			'rmrtype' => $this->input->post('rmrtype'),
			'q' => $this->input->post('q'),
			'rqd' => $this->input->post('rqd'),
			'jn' => $this->input->post('jn'),
			'jr' => $this->input->post('jr'),
			'ja' => $this->input->post('ja'),
			'jw' => $this->input->post('jw'),
			'srf' => $this->input->post('srf'),
			'esr' => $this->input->post('esr'),
			'b' => $this->input->post('b'),
			'ed' => $this->input->post('ed'),
			'p_roof' => $this->input->post('p_roof'),
			'conditional_a' => $this->input->post('cond_a'),
			'conditional_b' => $this->input->post('cond_b'),
			'support_type' => $this->input->post('support_type_result'),
			'qarea' => $this->input->post('qarea'),
			'kode' => $this->input->post('kode'),
			'notes' => $this->input->post('notes'),
			'q_classification' => $this->input->post('q_classification'),
			'location' => $this->input->post('location'),
			'l' => $this->input->post('l'),
			'spanmax' => $this->input->post('spanmax'),
			'q_table' => $this->input->post('q_table')
		);

		if ($data['rmrtype']=='bienawski') {
			$data['rmr']=(9*(log($data['q'],e))+44);
		}
		else if ($data['rmrtype']=='cameron') {
			$data['rmr']=(5*(log($data['q'],e))+60.8);
		}
		else if ($data['rmrtype']=='rutledge') {
			$data['rmr']=(5.9*(log($data['q'],e))+43);
		}
		else if ($data['rmrtype']=='abad') {
			$data['rmr']=(10.5*(log($data['q'],e))+41.8);
		}
		else if ($data['rmrtype']=='moreno') {
			$data['rmr']=(5.4*(log($data['q'],e))+55.2);
		}

		$rmr = $data['rmr'];
		if(($rmr <= 100) and ($rmr > 80)) {
			$rmrclass="I";
		} else if(($rmr <= 80) and ($rmr > 60)) {
			$rmrclass="II";
		} else if(($rmr <= 60) and ($rmr > 40)) {
			$rmrclass = "III";
		} else if (($rmr <= 40) and ($rmr > 20)) {
			$rmrclass = "IV";
		} else if ($rmr <=20 and $rmr >=0) {
			$rmrclass = "V";
		} else {
			$rmrclass = 0;
		}
		$notes = $data['notes'];
		
		$note_pars = explode(",", $notes);
		$i=0;
		foreach ($note_pars as $note) {
			$data['notes_table'][$i] = $this->calculation_model->get_notes($note);
			$i++;
		}
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		
		$data['rmr_table'] = $this->calculation_model->get_rmr("$rmrclass");
		$data['table'] = $this->calculation_model->get_data()->result();
		//var_dump($data['rmr_table']);
		if($data['id']==NULL) {
			$this->load->view("calculation_rmrresult", $data);
		} else {
			$this->load->view("edit_result", $data);
		}
	}
}
