<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('html', 'form', 'url_helper'));
		$this->load->model('login_model');
		$this->load->model('calculation_model');
		$this->load->model('user_model');
		$this->load->library('session');

		
	}

	public function index()
	{
		$this->load->view('home');
	}

	public function show_profil(){

		if($this->session->userdata('status') != "login"){
			redirect('Login');
		}

		$username = $this->session->userdata('username');
		$profil = $this->user_model->get_user($username);
		
		$data = array(
			'username' => $profil->username,
			'name' => $profil->name,
			'password' => $profil->password,
			'employee_number' => $profil->employee_number,
			'position' => $profil->position,
			'email' => $profil->email,
			'address' => $profil->address,
			'phone' => $profil->phone,
			'picture' => $profil->picture
		);
		if($data['picture']==NULL) {
			$data['picture'] = "ui-sam.jpg";
		}
		$this->load->view('profil', $data);
	}
	
	public function edit_data() {

		if($this->session->userdata('status') != "login"){
			redirect('Login');
		}

		$username = $this->input->post('username');
		$update = array(
			'username' => $this->input->post('username'),
			'password' => $this->input->post('password'),
			'name' => $this->input->post('name'),
			'employee_number' => $this->input->post('employee_number'),
			'position' => $this->input->post('position'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
			'phone' => $this->input->post('phone'),
			'picture' => $this->input->post('picture')
		);

		$this->user_model->edit_data($username, $update);
		$this->show_profil();
	}

	public function form_user() {
		$pesan = $this->input->get('pesan');
		if ($pesan == "Berhasil") {
			$this->load->view('pesan_sukses');
		} else if ($pesan == "Gagal"){
			$this->load->view('pesan_gagal');
		}
		$this->load->view('form_user');
	}

	public function save_data() {

		$input = array(
			'username' => $this->input->post('username'),
			'password' => $this->input->post('password'),
			'name' => $this->input->post('name'),
			'employee_number' => $this->input->post('employee_number'),
			'position' => $this->input->post('position'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
			'phone' => $this->input->post('phone'),
			'picture' => $this->input->post('picture')
		);

		$cek = $this->user_model->get_user($input['username']);
		if ($cek>0) {
			$pesan="Gagal";
		} else {
			$pesan = $this->user_model->input_data($input);
		}
		redirect('User/form_user?pesan='.$pesan);
	}
}
?>