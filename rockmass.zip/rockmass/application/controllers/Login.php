<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('html', 'form', 'url_helper'));
		$this->load->model('login_model');
		$this->load->library('session');
	}

	public function index()
	{
		$this->load->view('login');
	}

	public function ceklogin()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$validate = $this->login_model->validate_login($username, $password);
		if ( ! is_null($validate))
		{
			$data_session = array(
				'username' => $validate->username,
				'status' => "login",
				'picture' => $validate->picture,
				'name' => $validate->name
			);

			$this->session->set_userdata($data_session);

			redirect('Home');
		}
		else
		{
			$this->load->view('pesan_gagal');
			$this->load->view('login');
		}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect('Login');
	}
}