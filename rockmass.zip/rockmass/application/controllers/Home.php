<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->helper(array('html', 'form', 'url_helper'));
		$this->load->model('login_model');
		$this->load->model('calculation_model');
		$this->load->model('user_model');
		$this->load->library('session');

		if($this->session->userdata('status') != "login"){
			redirect('Login');
		}
	}

	public function index()
	{
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		$this->load->view('home', $data);
		
	}

	public function calculation_form() {
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');

		$data['rqd'] = $this->calculation_model->get_rqd();
		$data['jn'] = $this->calculation_model->get_jn();
		$data['jr'] = $this->calculation_model->get_jr();
		$data['ja'] = $this->calculation_model->get_ja();
		$data['jw'] = $this->calculation_model->get_jw();
		$data['esr'] = $this->calculation_model->get_esr();
		$data['srf'] = $this->calculation_model->get_srf();
		
		$this->load->view('calculation_form', $data);
	}

	public function save_data() {

		$input = array (
			'username_admin' => $this->session->userdata('username'),
			'date' => date("Y-m-d H:i:s"),
			'location' => $this->input->post('location'),
			'rqd' => $this->input->post('rqd'),
			'jn' => $this->input->post('jn'),
			'jr' => $this->input->post('jr'),
			'ja' => $this->input->post('ja'),
			'jw' => $this->input->post('jw'),
			'srf' => $this->input->post('srf'),
			'esr' => $this->input->post('esr'),
			'b' => $this->input->post('b'),
			'ed' => $this->input->post('ed'),
			'qresult' => $this->input->post('qresult'),
			'rmr_type' => $this->input->post('rmr_type'),
			'rmr_result' => $this->input->post('rmr_result'),
			'l' => $this->input->post('l'),
			'spanmax' => $this->input->post('spanmax'),
			'p_roof' => $this->input->post('p_roof'),
			'cond_a' => $this->input->post('cond_a'),
			'cond_b' => $this->input->post('cond_b'),
			'q_table' => $this->input->post('q_table'),
			'rmr_table' => $this->input->post('rmr_table')
		);

		$this->calculation_model->input_data($input);
		$data['hasil'] = $this->calculation_model->get_data()->result();
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		$this->load->view('tampil_data', $data);
	}

	public function delete_data() {
		$data['pict'] = $this->session->userdata('picture');
		$data['nama'] = $this->session->userdata('name');
		
		$id = $this->input->get('id');
		$this->calculation_model->delete_data($id);

		$data['hasil'] = $this->calculation_model->get_data()->result();
		$this->load->view('tampil_data', $data);
	}
}
?>