-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2019 at 12:05 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rockmass`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `username_admin` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `location` text NOT NULL,
  `rqd` float NOT NULL,
  `jn` float NOT NULL,
  `jr` float NOT NULL,
  `ja` float NOT NULL,
  `jw` float NOT NULL,
  `srf` float NOT NULL,
  `esr` float NOT NULL,
  `b` float NOT NULL,
  `ed` float NOT NULL,
  `qresult` float NOT NULL,
  `rmr_type` varchar(50) NOT NULL,
  `rmr_result` float NOT NULL,
  `l` float NOT NULL,
  `spanmax` float NOT NULL,
  `p_roof` float NOT NULL,
  `cond_a` float NOT NULL,
  `cond_b` float NOT NULL,
  `q_table` int(11) NOT NULL,
  `rmr_table` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `username_admin`, `date`, `location`, `rqd`, `jn`, `jr`, `ja`, `jw`, `srf`, `esr`, `b`, `ed`, `qresult`, `rmr_type`, `rmr_result`, `l`, `spanmax`, `p_roof`, `cond_a`, `cond_b`, `q_table`, `rmr_table`) VALUES
(2, 'admin', '2019-08-10 20:17:34', 'Cibaliung 69.7 m', 83, 15, 3, 4, 1, 1, 1, 20, 20, 4.15, 'bienawski', 56.808, 5, 3.53386, 0.414852, 5.53333, 0.75, 36, 3),
(3, 'admin', '2019-08-07 23:43:30', 'Cibaliung 71.7 m', 85.9, 9, 3, 4, 1, 1, 1, 20, 20, 7.15833, 'bienawski', 61.7145, 5, 4.39496, 0.345917, 9.54444, 0.333333, 36, 2),
(4, 'admin', '2019-08-07 23:48:57', 'Cibaliung 74.7 m', 77.2, 15, 1.5, 4, 1, 1, 1, 20, 20, 1.93, 'bienawski', 49.9177, 5, 2.60167, 1.07091, 5.14667, 0.1, 50, 3),
(5, 'admin', '2019-08-08 00:11:41', 'CIbaliung 76.5 m', 89.5, 9, 3, 4, 1, 1, 1, 20, 20, 7.45833, 'bienawski', 62.084, 5, 4.46773, 0.341215, 9.94444, 0.333333, 36, 2),
(6, 'admin', '2019-08-08 00:13:28', 'Cibaliung 83.2 m', 90.6, 9, 3, 4, 1, 1, 1, 20, 20, 7.55, 'bienawski', 62.1939, 5, 4.48961, 0.339828, 10.0667, 0.333333, 36, 2),
(7, 'admin', '2019-08-08 00:14:22', 'Cibaliung 89.5 m', 85, 12, 3, 4, 1, 1, 1, 20, 20, 5.3125, 'bienawski', 59.0306, 5, 3.90076, 0.38207, 7.08333, 0.25, 36, 3),
(8, 'admin', '2019-08-25 17:31:35', 'Cibaliung 92.1 m', 86.7, 9, 3, 4, 0.66, 1, 1, 20, 20, 4.7685, 'bienawski', 58.0583, 5, 3.73579, 0.396079, 9.63333, 0.75, 36, 3),
(9, 'admin', '2019-08-25 18:43:09', 'Cibaliung 97.1 m', 79.1, 12, 3, 4, 0.66, 1, 1, 20, 20, 3.26288, 'bienawski', 54.6435, 5, 3.20974, 0.449478, 6.59167, 0.75, 47, 3),
(10, 'admin', '2019-08-08 00:18:13', 'CIbaliung 98.7 m', 74.7, 9, 1.5, 4, 0.66, 1, 1, 20, 20, 2.05425, 'bienawski', 50.4792, 5, 2.66742, 1.04887, 8.3, 0.166667, 47, 3),
(11, 'admin', '2019-08-08 00:18:55', 'Cibaliung 100.7 m', 83.1, 4, 3, 4, 1, 1, 1, 20, 20, 15.5813, 'bienawski', 68.7146, 5, 5.99889, 0.266916, 20.775, 0.75, 24, 2),
(12, 'admin', '2019-08-29 13:49:49', 'Cibaliung 109.8 m', 77.1, 6, 1.5, 4, 1, 1, 1, 20, 20, 4.81875, 'bienawski', 58.1526, 5, 3.75149, 0.789394, 12.85, 0.375, 36, 3),
(13, 'admin', '2019-08-08 00:20:49', 'Cibaliung 112.3 m', 80.5, 6, 1.5, 4, 1, 1, 1, 20, 20, 5.03125, 'bienawski', 58.541, 5, 3.81681, 0.77812, 13.4167, 0.25, 36, 3),
(15, 'marella', '2019-08-08 00:46:34', 'Cibitung Decline 990.7 m - 993.1 m', 49, 9, 3, 6, 0.66, 1, 1.6, 2.4, 1.5, 1.79667, 'bienawski', 49.2734, 1.475, 4.04517, 0.548386, 5.44444, 0.333333, 0, 3),
(16, 'marella', '2019-08-09 16:11:43', 'Cibitung Decline 993.1 m - 994.3 m', 45.7, 9, 2, 6, 0.66, 1, 1.6, 1.2, 0.75, 1.11711, 'bienawski', 44.9967, 1.3625, 3.34494, 0.963758, 5.07778, 0.222222, 0, 3),
(17, 'marella', '2019-08-09 16:15:01', 'Cibitung Decline 994.3 m - 997.1 m', 45.7, 6, 2, 4, 0.66, 1, 1.6, 2.9, 1.8125, 2.5135, 'bienawski', 52.2951, 1.52188, 4.6266, 0.735485, 7.61667, 0.333333, 0, 3),
(18, 'marella', '2019-08-09 16:16:59', 'Cibitung Decline 997.1 m - 998.3 m', 42.4, 6, 3, 4, 0.5, 1, 1.6, 1.2, 0.75, 2.65, 'bienawski', 52.771, 1.3625, 4.72551, 0.481756, 7.06667, 0.5, 0, 3),
(19, 'marella', '2019-08-09 16:18:18', 'Cibitung Decline 998.3 m - 1000.7 m', 42.4, 4, 2, 4, 0.5, 1, 1.6, 2.4, 1.5, 2.65, 'bienawski', 52.771, 1.475, 4.72551, 0.722633, 10.6, 0.5, 0, 3),
(20, 'marella', '2019-08-09 17:25:53', 'Cibitung Ramp Up 36.9 m - 38.5 m', 72.1, 6, 3, 3, 1, 1, 1.6, 1.6, 1, 12.0167, 'bienawski', 66.3766, 1.4, 8.65095, 0.291059, 12.0167, 0.5, 0, 2),
(21, 'marella', '2019-08-09 17:31:18', 'Cibitung Ramp Up 38.5 m - 40 m', 68.8, 6, 2, 4, 1, 1, 1.6, 1.5, 0.9375, 5.73333, 'bienawski', 59.7167, 1.39062, 6.43447, 0.558724, 11.4667, 0.333333, 0, 3),
(22, 'marella', '2019-08-09 17:35:33', 'Cibitung Ramp Up 40 m - 42.6 m', 68.8, 6, 2, 4, 1, 1, 1.6, 2.6, 1.625, 5.73333, 'bienawski', 59.7167, 1.49375, 6.43447, 0.558724, 11.4667, 0.333333, 0, 3),
(23, 'marella', '2019-08-09 17:36:54', 'Cibitung Ramp Up 42.6 m - 44.2 m', 58.9, 6, 2, 4, 1, 1, 1.6, 1.6, 1, 4.90833, 'bienawski', 58.3184, 1.4, 6.04677, 0.588422, 9.81667, 0.333333, 0, 3),
(24, 'marella', '2019-08-09 17:39:13', 'Cibitung Ramp Up 44.2 m - 46.4 m', 58.9, 9, 3, 4, 1, 1, 1.6, 2.2, 1.375, 4.90833, 'bienawski', 58.3184, 1.45625, 6.04677, 0.392281, 6.54444, 0.333333, 0, 3),
(25, 'admin', '2019-08-10 19:45:40', 'CBT_1001_XC7_NTH 2.1 m', 46, 4, 3, 4, 0.66, 1, 1, 5, 5, 5.6925, 'bienawski', 59.6523, 2.75, 4.01006, 0.373371, 11.5, 0.75, 31, 3),
(26, 'admin', '2019-08-10 19:51:55', 'CBT_1001_XC7_NTH 5.6 m', 48, 4, 3, 4, 0.66, 1, 1, 5, 5, 5.94, 'bienawski', 60.0354, 2.75, 4.07891, 0.368112, 12, 0.75, 31, 2),
(27, 'admin', '2019-08-10 19:55:22', 'CBT_1001_XC7_NTH 6.6 m', 49, 4, 3, 4, 0.66, 1, 1, 5, 5, 6.06375, 'bienawski', 60.221, 2.75, 4.1127, 0.365591, 12.25, 0.75, 31, 2),
(28, 'admin', '2019-08-10 19:56:32', 'CBT_1001_XC7_NTH 8 m', 50, 6, 3, 4, 0.66, 1, 1, 5, 5, 4.125, 'bienawski', 56.7536, 2.75, 3.52533, 0.415688, 8.33333, 0.5, 31, 3),
(29, 'admin', '2019-08-10 19:57:09', 'CBT_1001_XC7_NTH 12.1 m', 50, 6, 3, 4, 0.66, 1, 1, 5, 5, 4.125, 'bienawski', 56.7536, 2.75, 3.52533, 0.415688, 8.33333, 0.5, 31, 3),
(30, 'admin', '2019-08-10 19:58:37', 'CBT_1001_XC7_NTH 15.1 m', 48, 4, 3, 4, 0.66, 1, 1, 5, 5, 5.94, 'bienawski', 60.0354, 2.75, 4.07891, 0.368112, 12, 0.75, 31, 2),
(31, 'admin', '2019-08-10 19:59:51', 'CBT_1001_XC7_NTH 17.4 m', 47, 4, 3, 4, 0.66, 1, 1, 5, 5, 5.81625, 'bienawski', 59.8459, 2.75, 4.04471, 0.370704, 11.75, 0.75, 31, 3),
(32, 'admin', '2019-08-10 20:00:40', 'CBT_1001_XC7_NTH 19.1 m', 46, 4, 3, 4, 0.66, 1, 1, 5, 5, 5.6925, 'bienawski', 59.6523, 2.75, 4.01006, 0.373371, 11.5, 0.75, 31, 3),
(33, 'admin', '2019-08-29 12:38:31', 'CBT_1001_XC7_NTH 21.7 m', 48, 6, 3, 4, 0.66, 1, 1, 20, 20, 3.96, 'bienawski', 56.3862, 5, 3.46823, 0.421383, 8, 0.75, 47, 3),
(34, 'admin', '2019-08-29 12:40:29', 'CBT_1001_XC7_NTH 23.5 m', 46, 4, 3, 4, 0.66, 1, 1, 20, 20, 5.6925, 'bienawski', 59.6523, 5, 4.01006, 0.373371, 11.5, 0.75, 36, 3);

-- --------------------------------------------------------

--
-- Table structure for table `dataku`
--

CREATE TABLE `dataku` (
  `id` int(11) NOT NULL,
  `username_admin` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `location` text NOT NULL,
  `rqd` float NOT NULL,
  `jn` float NOT NULL,
  `jr` float NOT NULL,
  `ja` float NOT NULL,
  `jw` double NOT NULL,
  `srf` float NOT NULL,
  `esr` float NOT NULL,
  `span` float NOT NULL,
  `ed` double NOT NULL,
  `qresult` double NOT NULL,
  `l` float NOT NULL,
  `spanmax` float NOT NULL,
  `p_roof` double NOT NULL,
  `cond_a` double NOT NULL,
  `cond_b` double NOT NULL,
  `support_type_result` text NOT NULL,
  `qarea` int(11) NOT NULL,
  `kode` int(11) NOT NULL,
  `notes` varchar(30) NOT NULL,
  `rmr_type` varchar(30) NOT NULL,
  `rmr_value` float NOT NULL,
  `rmr_class` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dataku`
--

INSERT INTO `dataku` (`id`, `username_admin`, `date`, `location`, `rqd`, `jn`, `jr`, `ja`, `jw`, `srf`, `esr`, `span`, `ed`, `qresult`, `l`, `spanmax`, `p_roof`, `cond_a`, `cond_b`, `support_type_result`, `qarea`, `kode`, `notes`, `rmr_type`, `rmr_value`, `rmr_class`) VALUES
(15, 'Admin', '2019-06-19 16:55:54', 'Titik A Yogyakarta', 10, 4, 2, 1, 5, 5, 2, 20, 10, 5, 0, 0, 0.58480354764257, 2.5, 0.5, 'B (tg) 1-1.5 m + S (mr) 2-3 cm', 18, 3, 'I', '', 0, ''),
(17, 'Admin', '2019-07-22 21:34:57', 'Bantul', 10, 2, 4, 2, 0.1, 10, 1, 2, 2, 0.1, 0, 0, 0.25390256315751, 5, 2, 'B (utg) 1m + S (mr) 5 cm', 29, 2, 'No notes', '', 0, ''),
(18, 'Admin', '2019-07-23 00:10:42', 'Yogyakarta A', 75, 6, 2, 1, 0.1, 5, 1, 8, 8, 0.5, 0, 0, 1.2599210498949, 12.5, 0.33333333333333, 'S (mr) 10-20 cm + B (tg) 1 m', 27, 4, 'VIII,X,XI', 'cameron', 57.3343, 'III'),
(19, 'Admin', '2019-07-25 00:43:05', 'Yogyakarta C', 80, 2, 3, 1, 0.33, 1, 1.3, 20, 15.384615384615, 39.6, 0, 0, 0.046100690083893, 40, 1.5, 'B (tg) 1.5-2 m + clm', 14, 1, 'I,II', 'bienawski', 77.1095, 'II'),
(20, 'Admin', '2019-07-30 16:07:56', 'Decline Area', 49, 9, 3, 6, 0.66, 1, 1.6, 4.34, 2.7125, 1.7966666666667, 0, 0, 0.54838584658273, 5.4444444444444, 0.33333333333333, 'S 2.5-5 cm', 21, 2, 'I', 'bienawski', 49.2734, 'III'),
(21, 'Admin', '2019-08-01 00:14:21', 'Cibaliung 69.7 m', 83, 15, 3, 4, 1, 1, 1, 20, 20, 4.15, 0, 0, 0.41485154200701, 5.5333333333333, 0.2, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'bienawski', 56.808, 'III'),
(22, 'Admin', '2019-08-01 00:19:46', 'Cibaliung 71.7 m', 85.9, 9, 3, 4, 1, 1, 1, 20, 20, 7.1583333333333, 0, 0, 0.34591662499808, 9.5444444444444, 0.33333333333333, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'bienawski', 61.7145, 'II'),
(23, 'Admin', '2019-08-01 00:25:37', 'Cibaliung 74.7 m', 77.2, 15, 1.5, 4, 1, 1, 1, 20, 20, 1.93, 0, 0, 1.0709099826781, 5.1466666666667, 0.1, 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 24, 2, 'I,II,IV', 'cameron', 64.0876, 'II'),
(24, 'Admin', '2019-08-07 17:53:24', 'CIbaliung 76.5 m', 89.5, 9, 3, 4, 1, 1, 1, 20, 20, 7.4583333333333, 5, 4.46773, 0.34121502339819, 9.9444444444444, 0.33333333333333, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'rutledge', 54.8551, 'III'),
(25, 'Admin', '2019-08-01 00:45:53', 'Cibaliung 83.2 m', 90.6, 9, 3, 4, 1, 1, 1, 20, 20, 7.55, 0, 0, 0.33982846755767, 10.066666666667, 0.33333333333333, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'rutledge', 54.9271, 'III'),
(26, 'Admin', '2019-08-01 00:49:09', 'Cibaliung 89.5 m', 85, 12, 3, 4, 1, 1, 1, 20, 20, 5.3125, 0, 0, 0.38206954975551, 7.0833333333333, 0.25, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'moreno', 64.2183, 'II'),
(27, 'Admin', '2019-08-07 14:32:11', 'Cibaliung 92.1', 86.7, 9, 3, 4, 0.66, 1, 1, 20, 20, 4.7685, 0, 0, 0.39607869154206, 9.6333333333333, 0.33333333333333, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'abad', 58.2013, 'III'),
(28, 'Admin', '2019-08-07 14:51:52', 'Cibaliung 97.1', 79.1, 12, 3, 4, 0.66, 1, 1, 20, 20, 3.262875, 0, 0, 0.44947816117069, 6.5916666666667, 0.25, 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 23, 1, 'I,II,IV,VII', 'bienawski', 54.6435, 'III'),
(29, 'Admin', '2019-08-07 14:53:21', 'CIbaliung 98.7 m', 74.7, 9, 1.5, 4, 0.66, 1, 1, 20, 20, 2.05425, 0, 0, 1.0488683277434, 8.3, 0.16666666666667, 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 23, 1, 'I,II,IV,VII', 'bienawski', 50.4792, 'III'),
(30, 'Admin', '2019-08-07 14:55:15', 'Cibaliung 100.7 m', 83.1, 4, 3, 4, 1, 1, 1, 20, 20, 15.58125, 0, 0, 0.26691602116229, 20.775, 0.75, 'B (tg) 1.5-2 m + clm', 15, 1, 'I,II,IV', 'bienawski', 68.7146, 'II'),
(31, 'Admin', '2019-08-07 14:56:23', 'Cibaliung 109.8 m', 77.1, 6, 1.5, 4, 1, 1, 1, 20, 20, 4.81875, 0, 0, 0.78939421274194, 12.85, 0.25, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'bienawski', 58.1526, 'III'),
(32, 'Admin', '2019-08-07 14:57:27', 'Cibaliung 112.3 m', 80.5, 6, 1.5, 4, 1, 1, 1, 20, 20, 5.03125, 0, 0, 0.77812034505173, 13.416666666667, 0.25, 'B (tg) 1-2 m + S (mr) 10-15 cm', 19, 1, 'I,II,IV', 'bienawski', 58.541, 'III'),
(33, 'Admin', '2019-08-07 17:44:23', 'Cibitung Decline 990.7 m - 993.1 ma', 49, 9, 3, 6, 0.66, 1, 1.6, 2.4, 1.5, 1.7966666666667, 1.475, 4.045, 0.54838584658273, 5.4444444444444, 0.33333333333333, '0', 0, 0, '0', 'bienawski', 49.2734, 'III');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `employee_number` varchar(30) NOT NULL,
  `position` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `picture` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`username`, `password`, `name`, `employee_number`, `position`, `email`, `address`, `phone`, `picture`) VALUES
('admin', 'admin', 'Administrator', '909909090', 'Admin', 'admin@gmail.com', 'Jl. Babarsari Yogyakarta', '089999999999', 'profile.png'),
('marella', 'marella', 'Marella', '100110', 'Admin', 'marella@yahoo.com', ' Jl. Solo no. 10 Yogyakarta', '089999999999', '');

-- --------------------------------------------------------

--
-- Table structure for table `esr_table`
--

CREATE TABLE `esr_table` (
  `id_esr` int(11) NOT NULL,
  `esr_category` varchar(2) NOT NULL,
  `esr_description` text NOT NULL,
  `esr_value` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `esr_table`
--

INSERT INTO `esr_table` (`id_esr`, `esr_category`, `esr_description`, `esr_value`) VALUES
(1, 'A', 'Temporary mine openings \n(Bukaan tambang sementara)', '3-5'),
(2, 'B', 'Vertical shaft : Circular section. \n(Poros vertikal: Bagian melingkar)', '2.5'),
(3, 'B', 'Vertical shaft : Rectangular/squre section.\n(Poros vertikal: Bagian persegi panjang / persegi)', '2'),
(4, 'C', 'Permanent mine openings, water tunnels for hydropower (excluding high-pressure penstocks), pilot tunnels, drifts, and headings for large excavations.\n(Bukaan tambang permanen, terowongan air untuk pembangkit listrik tenaga air, pos untuk penggalian besar)', '1.6'),
(5, 'D', 'Storage caverns, water treatment plants, minor highway and railroad tunnels, surge chambers, access tunnels.\n(Gua penyimpanan, instalasi pengolahan air, terowongan jalan raya kecil dan rel kereta api, ruang gelombang, terowongan akses)', '1.3'),
(6, 'E', 'Power stations, major highway or railroad tunnels, civil defense chambers, portals, intersections.\n(Pembangkit listrik, terowongan jalan raya atau kereta api utama, ruang pertahanan sipil, portal, persimpangan)', '1'),
(7, 'F', 'Underground nuclear power stations, railroad stations, factories \n(Pembangkit listrik tenaga nuklir bawah tanah, stasiun kereta api, pabrik)', '0.8');

-- --------------------------------------------------------

--
-- Table structure for table `ja_table`
--

CREATE TABLE `ja_table` (
  `id_ja` int(11) NOT NULL,
  `ja_kode` varchar(1) NOT NULL,
  `ja_description` text NOT NULL,
  `ja_value` varchar(30) NOT NULL,
  `ja_approx` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ja_table`
--

INSERT INTO `ja_table` (`id_ja`, `ja_kode`, `ja_description`, `ja_value`, `ja_approx`) VALUES
(1, 'A', 'Thightly healed, hard, non-softening, impermeable filling (Pengisian sempurna, keras, tidak halus, kedap air)', '0.75', ''),
(2, 'B', 'Unaltered joint walls, surface staining only (\nDinding sambungan yang tidak diubah, hanya pewarnaan permukaan yang tidak halus, pengisian kedap air)', '1', '25-35o'),
(3, 'C', 'Slightly altered joint walls, nonsoftening minerals coatings, sandy particles, clay-free disintegrated rock, etc. (\nDinding sambungan sedikit diubah, lapisan mineral tidak halus, partikel berpasir, batu hancur bebas tanah liat, dll.)', '2', '25-30o'),
(4, 'D', 'Silly or sandy clay coatings, small clay fraction (nonsoftening). (Pelapis tanah liat yang berpasir, fraksi lempung kecil (nonsoftening))', '3', '20-25o'),
(5, 'E', 'Softening or low-friction clay mineral coatings, i.e., kaolinite, mica. Also chlorite, talc, gypsum, and graphite, etc., and small quantities of swelling clays (discontinuous coatings, 1-2 mm or less in thickness). (Pelapis mineral lempung atau gesekan rendah dan sedikit lempung bengkak (pelapisan terputus, ketebalan 1-2 mm atau kurang))', '4', '8-16o'),
(6, 'F', 'Sandy particles, clay-free disintegrated rock, etc. (Partikel berpasir, batuan hancur bebas tanah liat, dll)', '4', '25-30o'),
(7, 'G', 'Strongly over-consolidated, nonsofterning clay mineral fillings (continuous, <5 mm in thickness) (Penambalan mineral lempung yang sangat tidak terkonsolidasi dan sangat terkonsentrasi)', '6', '16-24o'),
(8, 'H', 'Medium or low over-consolidation, softening, clay mineral fillings. (continuous, <5 mm in thickness)', '8', '12-16o'),
(9, 'J', 'Swelling clay fillings, i.e., montmorillonite (continuous, < mm in thickness). Value of Ja depends on percentage of swelling clay-sized particles, and access to water, etc. (Tambalan tanah liat yang mengembang. Nilai Ja tergantung pada persentase pembengkakan partikel seukuran tanah liat, dan akses ke air, dll.)', '8.0-12.0', '6-12o');

-- --------------------------------------------------------

--
-- Table structure for table `jn_table`
--

CREATE TABLE `jn_table` (
  `id_jn` int(11) NOT NULL,
  `jn_kode` varchar(1) NOT NULL,
  `jn_description` text NOT NULL,
  `jn_value` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jn_table`
--

INSERT INTO `jn_table` (`id_jn`, `jn_kode`, `jn_description`, `jn_value`) VALUES
(1, 'A', 'Massive, no or few joints. (Masif, tidak ada atau sedikit sendi)', '0.5-1.0'),
(2, 'B', 'One joint set (satu set kekar)', '2'),
(3, 'C', 'One joint set plus random (satu set kekar plus random)', '3'),
(4, 'D', 'Two joint sets (dua set kekar)', '4'),
(5, 'E', 'Two joint sets plus random (dua set kekar plus random)', '6'),
(6, 'F', 'Three joint set (tiga set kekar)', '9'),
(7, 'G', 'Three joint set plus random (tiga set kekar plus random)', '12'),
(8, 'H', 'Four or more joint sets, random, heavily jointed, ?sugar cube, etc. (Empat atau lebih set sambungan, acak, bersendi banyak)', '15'),
(9, 'I', 'Chorused rock, earthlike', '20');

-- --------------------------------------------------------

--
-- Table structure for table `jr_table`
--

CREATE TABLE `jr_table` (
  `id_jr` int(11) NOT NULL,
  `jr_kode` varchar(1) NOT NULL,
  `jr_description` text NOT NULL,
  `jr_value` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jr_table`
--

INSERT INTO `jr_table` (`id_jr`, `jr_kode`, `jr_description`, `jr_value`) VALUES
(1, 'A', 'Discontinuous joints. \n(Sendi terputus-putus)', '4'),
(2, 'B', 'Rough and irregular undulating. (Bergelombang kasar dan tidak beraturan)', '3'),
(3, 'C', 'Smooth undulating (Bergelombang halus)', '2'),
(4, 'D', 'Slickensided undulating (Bergelombang licin)', '1.5'),
(5, 'E', 'Rough and irregular planar (Planar kasar dan tidak beraturan)', '1.5'),
(6, 'F', 'Smooth planar (Planar halus)', '1'),
(7, 'G', 'Slickensided planar (Planar licin)', '0.5'),
(8, 'H', 'Zones containing clay minerals thick enough to prevent rock wall contact (Zona yang mengandung mineral tanah liat cukup tebal untuk mencegah kontak dinding batu)', '1.0 (nominal)'),
(9, 'I', 'Sandy, gravely or chorused zone thick enough to prevent rock wall contact (Zona berpasir, serius atau chorused cukup tebal untuk mencegah kontak dinding batu)', '1.0 (nominal)');

-- --------------------------------------------------------

--
-- Table structure for table `jw_table`
--

CREATE TABLE `jw_table` (
  `id_jw` int(11) NOT NULL,
  `jw_kode` varchar(1) NOT NULL,
  `jw_description` text NOT NULL,
  `jw_value` varchar(30) NOT NULL,
  `jw_water_press` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jw_table`
--

INSERT INTO `jw_table` (`id_jw`, `jw_kode`, `jw_description`, `jw_value`, `jw_water_press`) VALUES
(1, 'A', 'Dry excavations or minor inflow, i.e., 5 L/min locally (Penggalian kering atau aliran kecil)', '1', '<1'),
(2, 'B', 'Medium inflow or pressure occasional outwash of joint fillings (Aliran masuk sedang atau tekanan kadang-kadang melebihi pengisian tambalan)', '0.66', '1.0 - 2.5'),
(3, 'C', 'Large inflow or high pressure in competent rock with unfilled joints (Aliran besar atau tekanan tinggi pada batu kompeten dengan sambungan yang tidak terisi)', '0.5', '2.5 - 10.0'),
(4, 'D', 'Large inflow or high pressure, considerable outwash of joint fillings (Aliran besar atau tekanan tinggi, jauh melebihi isi tambalan)', '0.33', '2.5 - 10.0'),
(5, 'E', 'Exceptionally high inflow or water pressure at blasting, decaying with time (Aliran masuk sangat tinggi atau tekanan air pada peledakan, membusuk seiring waktu)', '0.2 - 0. 1', '> 10.0'),
(6, 'F', 'Exceptionally high inflow or water pressure continuing without noticeable decay (Inflow tinggi atau tekanan air terus berlanjut tanpa kerusakan yang nyata)', '0. 1 - 0.05', '> 10.0'),
(7, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `q_notes`
--

CREATE TABLE `q_notes` (
  `notes_number` varchar(5) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `q_notes`
--

INSERT INTO `q_notes` (`notes_number`, `notes`) VALUES
('0', 'No notes'),
('I', 'For cases of heavy rock bursting or “popping” tensioned bolts with enlarged bearing plates often used, with spacing of about 1m (occasionally down to 0.8 m). Final support when “popping” activity ceases'),
('II', 'Several bolt lengths often used in same excavation, i.e., 3, 5, and 7 m.'),
('III', 'Several bolt lengths often used in same excavation, i.e., 2, 3, and 4 m.'),
('IV', 'Tensioned cable anchors often used to supplement bolt support pressures. Typical spacing 2-4 m.'),
('IX', 'Cases not involving swelling clay or squeezing rock.'),
('V', 'Several bolt lengths often used in same excavation, i.e., 6, 8, and 10 m.'),
('VI', 'Tensioned cable anchors often used to supplement bolt support pressures. Typical spacing 4-6 m.'),
('VII', 'Several of the older-generation power stations in this category employ systematic or spot bolting with areas of chain-link mesh, and free-span concrete roof arch roof (25-40 cm) as permanent support.'),
('VIII', 'Cases involving swelling, e.g., montmorillonite clay (with access of water). Room for expansion behind the supports is used in cases of heavy swelling. Drainage measures are used where possible.'),
('X', 'Cases involving squeezing rock. Heavy rigid support is generally used as permanent support'),
('XI', 'According to the authors [Borton et al.] experience, in cases of swelling or squeezing, the temporary support required before concrete (or shotcrete) arches are formed may consist of bolting (tensioned shell-expansion type) if the value of RQD/Jn is sufficiently high (i.e., > 15), possibly combined with shotcrete. If the rock mass is very heavily jointed or crushed (i.e., RQD/Jn < 15, for example, a “sugar cube” shear zone in quartzite), then the temporary support may consist of up to several applications of shotcrete. Systematic bolting (tensioned) may be added after casting the concrete, but it may not be effective when RQD/Jn < 15, or when a lot of clay is present, unless the bolts are grouted before tensioning. A sufficient length of anchored bolt might also be obtained using quick-setting resin anchors in these extremely poor-quality rock masses. Serious occurrences of swelling and/or squeezing rock may require that concrete arches are taken right up to the face, possibly using a shield as temporary shuttering. Temporary support of the working face may also be required in these cases.'),
('XII', 'For reasons of safety, the multiple drift method will often be needed during excavation and supporting of roof arch. Categories 16, 20, 24, 28, 32, 35 (span/ESR > 15 m only).'),
('XIII', 'Multiple drift method usually needed during excavation and support of arch, walls, and floor in cases of heavy squeezing, Category 28 (span/ESR > 10 m only).');

-- --------------------------------------------------------

--
-- Table structure for table `q_system`
--

CREATE TABLE `q_system` (
  `id_q` int(11) NOT NULL,
  `support_category` int(11) NOT NULL,
  `keterangan` varchar(20) NOT NULL,
  `q_system` varchar(20) NOT NULL,
  `conditional_a` varchar(20) NOT NULL,
  `conditional_b` varchar(20) NOT NULL,
  `span` varchar(20) NOT NULL,
  `pb` int(11) NOT NULL,
  `span_esr` varchar(20) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `type_of_support` varchar(200) NOT NULL,
  `notes` set('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `q_system`
--

INSERT INTO `q_system` (`id_q`, `support_category`, `keterangan`, `q_system`, `conditional_a`, `conditional_b`, `span`, `pb`, `span_esr`, `kode`, `type_of_support`, `notes`) VALUES
(0, 0, '0', '0', '0', '0', '0', 0, '0', '0', '0', ''),
(1, 1, 'c', '1000-400', '', '', '', 0, '20-40', 'a', 'sb (utg)', NULL),
(2, 2, 'c', '1000-400', '', '', '', 0, '30-60', 'a', 'sb (utg)', NULL),
(3, 3, 'c', '1000-400', '', '', '', 0, '46-80', 'a', 'sb (utg)', ''),
(4, 4, 'c', '1000-400', '', '', '', 0, '65-100', 'a', 'sb (utg)', ''),
(5, 5, 'c', '400-100', '', '', '', 0, '12-30', 'a', 'sb (utg)', ''),
(6, 6, 'c', '400-100', '', '', '', 0, '19-45', 'a', 'sb (utg)', ''),
(7, 7, 'c', '400-100', '', '', '', 0, '30-65', 'a', 'sb (utg)', ''),
(8, 8, 'c', '400-100', '', '', '', 0, '48-88', 'a', 'sb (utg)', ''),
(9, 9, '', '100-40', '>= 20', '', '', 0, '8.5-19', 'a', 'sb (utg)', ''),
(10, 9, '', '100-40', '< 20', '', '', 0, '8.5-19', 'b', 'B (utg) 2.5-3 m', ''),
(11, 10, '', '100-40', '>= 30', '', '', 0, '14-30', 'a', 'B (utg) 2-3 m', ''),
(12, 10, '', '100-40', '< 30', '', '', 0, '14-30', 'b', 'B (utg) 1.5-2 m + clm', ''),
(13, 11, 'c', '100-40', '>= 30', '', '', 0, '23-48', 'a', 'B (tg) 2-3 m', NULL),
(14, 11, 'c', '100-40', '< 30', '', '', 0, '23-48', 'b', 'B (tg) 1.5-2 m + clm', ''),
(15, 12, 'c', '100-40', '>= 30', '', '', 0, '40-72', 'a', 'B (tg) 2-3 m', ''),
(16, 12, 'c', '100-40', '<30', '', '', 0, '40-72', 'b', 'B (tg) 1.5-2 m + clm', ''),
(17, 13, '', '40-10', '>= 10', '>= 1.5', '', 1, '5-14', 'a', 'sb (utg)', 'I'),
(18, 13, '', '40-10', '>= 10', '< 1.5', '', 1, '5-14', 'b', 'B (utg) 1.5-2 m', 'I'),
(19, 13, '', '40-10', '< 10', '>= 1.5', '', 1, '5-14', 'c', 'B (utg) 1.5-2 m', 'I'),
(20, 13, '', '40-10', '< 10', '< 1.5', '', 1, '5-14', 'd', 'B (utg) 1.5-2 m + S 2-3 cm', 'I'),
(21, 14, '', '40-10', '>= 10', '', '>= 15', 1, '9-23', 'a', 'B (tg) 1.5-2 m + clm', 'I,II'),
(22, 14, '', '40-10', '< 10', '', '>= 15', 1, '9-23', 'b', 'B (tg) 1.5-2 m + S (mr) 5-10 cm', 'I,II'),
(23, 14, '', '40-10', '', '', '< 15', 1, '9-23', 'c', 'B (utg) 1.5-2 m + clm', 'I,III'),
(24, 15, '', '40-10', '> 10', '', '', 1, '15-40', 'a', 'B (tg) 1.5-2 m + clm', 'I,II,IV'),
(25, 15, '', '40-10', '<= 10', '', '', 1, '15-40', 'b', 'B (tg) 1.5-2 m + S (mr) 5-10 cm', 'I,II,IV'),
(26, 16, 'c, d', '40-10', '> 15', '', '', 1, '30-65', 'a', 'B (tg) 1.5-2 m + clm', 'I,V,VI'),
(27, 16, 'c, d', '40-10', '<= 15', '', '', 1, '30-65', 'b', 'B (tg) 1.5-2 m + S (mr) 10-15 cm', 'I,V,VI'),
(28, 17, '', '10-4', '> 30', '', '', 1, '3.5-9', 'a', 'sb (utg)', 'I'),
(29, 17, '', '10-4', '< 10', '', '>= 6', 1, '3.5-9', 'b', 'B (utg) 1-1.5 m + S 2-3 cm', 'I'),
(30, 17, '', '10-4', '< 10', '', '< 6', 1, '3.5-9', 'c', 'S 2-3 cm', 'I'),
(31, 17, '', '10-4', '', '', '', 1, '3.5-9', 'd', 'B (utg) 1-1.5 m', 'I'),
(32, 18, '', '10-4', '> 5', '', '>= 10', 1, '7-15', 'a', 'B (tg) 1-1.5 m + clm', 'I,III'),
(33, 18, '', '10-4', '> 5', '', '< 10', 1, '7-15', 'b', 'B (utg) 1-1.5 m + clm', 'I'),
(34, 18, '', '10-4', '<= 5', '', '>= 10', 1, '7-15', 'c', 'B (tg) 1-1.5 m + S (mr) 2-3 cm', 'I,III'),
(35, 18, '', '10-4', '<= 5', '', '< 10', 1, '7-15', 'd', 'B (utg) 1-1.5 m + S (mr) 2-3 cm', 'I'),
(36, 19, '', '10-4', '', '', '>= 20', 1, '12-29', 'a', 'B (tg) 1-2 m + S (mr) 10-15 cm', 'I,II,IV'),
(37, 19, '', '10-4', '', '', '< 20', 1, '12-29', 'b', 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 'I,II'),
(38, 20, 'c', '10-4', '', '', '>= 35', 1, '24-52', 'a', 'B (tg) 1-2 m + S (mr) 20-25 cm', 'I,V,VI'),
(39, 20, 'c', '10-4', '', '', '< 35', 1, '24-52', 'b', 'B (tg) 1-2 m + S (mr) 10-20 cm', 'I,II,IV'),
(40, 21, '', '4-1', '>= 12.5', '<= 0.75', '', 2, '2. 1-6.5', 'a', 'B (utg) 1m + S 2-3 cm', 'I'),
(41, 21, '', '4-1', '< 12.5', '< 0.75', '', 2, '2. 1-6.5', 'b', 'S 2.5-5 cm', 'I'),
(42, 21, '', '4-1', '', '>= 0.75', '', 2, '2. 1-6.5', 'c', 'B (utg) 1m + clm', 'I'),
(43, 22, '', '4-1', '<= 10', '> 1.0', '', 2, '4.5-11.5', 'a', 'S 2.5-7.5 cm', 'I'),
(44, 22, '', '4-1', '< 30', '<= 1.0', '', 2, '4.5-11.5', 'b', 'B (utg) 1m + S (mr) 25-5 cm', 'I'),
(45, 22, '', '4-1', '>= 30', '', '', 2, '4.5-11.5', 'c', 'B (utg) 1m', 'I'),
(46, 22, '', '4-1', '', '>1.0', '', 2, '4.5-11.5', 'd', 'B (utg) 1m', 'I'),
(47, 23, '', '4-1', '', '', '>= 15', 2, '8-24', 'a', 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 'I,II,IV,VII'),
(48, 23, '', '4-1', '', '', '< 15', 2, '8-24', 'b', 'B (utg) 1-1.5 m + S (mr) 10-15 cm', 'I'),
(49, 24, 'c, d', '4-1', '', '', '>= 30', 2, '18-46', 'a', 'B (tg) 1-1.5 m + S (mr) 15-30 cm', 'I,V,VI'),
(50, 24, 'c, d', '4-1', '', '', '< 30', 2, '18-46', 'b', 'B (tg) 1-1.5 m + S (mr) 10-15 cm', 'I,II,IV'),
(51, 25, '', '1.0-0.4', '> 10', '> 0.5', '', 2, '1.5-4.2', 'a', 'B (utg) 1m + mr or clm', 'I'),
(52, 25, '', '1.0-0.4', '<= 10', '> 0.5', '', 2, '1.5-4.2', 'b', 'B (utg) 1m + S (mr) 5 cm', 'I'),
(53, 25, '', '1.0-0.4', '', '<= 0.5', '', 2, '1.5-4.2', 'c', 'B (tg) 1m + S (Mr) 5 cm', 'I'),
(54, 26, '', '1.0-0.4', '', '', '', 2, '3.2-7.5', 'a', 'B (tg) 1m + S (mr) 5-7.5 cm', 'VIII,X,XI'),
(55, 26, '', '1.0-0.4', '', '', '', 2, '3.2-7.5', 'b', 'B (utg) 1m + S 2.5-5 cm', 'I,IX'),
(56, 27, '', '1.0-0.4', '', '', '>= 12', 2, '6-18', 'a', 'B (tg) 1m + S (mr) 7.5-10 cm', 'I,IX'),
(57, 27, '', '1.0-0.4', '', '', '< 12', 2, '6-18', 'b', 'B (utg) 1m + S (mr) 5-7.5 cm', 'I,IX'),
(58, 27, '', '1.0-0.4', '', '', '> 12', 2, '6-18', 'c', 'CCA 20-40 cm + B (tg) 1 m', 'VIII,X,XI'),
(59, 27, '', '1.0-0.4', '', '', '< 12', 2, '6-18', 'd', 'S (mr) 10-20 cm + B (tg) 1 m', 'VIII,X,XI'),
(60, 28, 'd', '1.0-0.4', '', '', '>= 30', 2, '15-38', 'a', 'B (tg) 1m + S (mr) 30-40 cm', 'I,IV,V,IX'),
(61, 28, 'd', '1.0-0.4', '', '', '< 30', 2, '15-38', 'b', 'B (tg) 1m + S (mr) 20-30 cm', 'I,II,IV,IX'),
(62, 28, 'd', '1.0-0.4', '', '', '< 20', 2, '15-38', 'c', 'B (tg) 1m + S (mr) 15-20 cm', 'I,II,IX'),
(63, 28, 'd', '1.0-0.4', '', '', '', 2, '15-38', 'd', 'CCA (sr) 30-100 cm + B (tg) 1 m', 'IV,VIII,X,XI'),
(64, 29, '', '0.4-0.1', '> 5', '> 0.25', '', 3, '1.0-3. 1', 'a', 'B (utg) 1m + S 2-3 cm', ''),
(65, 29, '', '0.4-0.1', '<= 5', '> 0.25', '', 3, '1.0-3. 1', 'b', 'B (utg) 1m + S (mr) 5 cm', ''),
(66, 29, '', '0.4-0.1', '', '<= 0.25', '', 3, '1.0-3. 1', 'c', 'B (tg) 1m + S (Mr) 5 cm', ''),
(67, 30, '', '0.4-0.1', '>= 5', '', '', 3, '2.2-6', 'a', 'B (tg) 1m + S 2.5-5 cm', 'IX'),
(68, 30, '', '0.4-0.1', '< 5', '', '', 3, '2.2-6', 'b', 'S (mr) 5-7.5 cm', 'IX'),
(69, 30, '', '0.4-0.1', '', '', '', 3, '2.2-6', 'c', 'B (tg) 1m + S (mr) 5-7.5 cm', 'VIII,X,XI'),
(70, 31, '', '0.4-0.1', '> 4', '', '', 3, '4-12.5', 'a', 'B (tg) 1m + S (mr) 5-12.5 cm', 'IX'),
(71, 31, '', '0.4-0.1', '<= 4', '', '', 3, '4-12.5', 'b', 'S (mr) 7.5-25 cm', 'IX'),
(72, 31, '', '0.4-0.1', '< 1.5', '', '', 3, '4-12.5', 'c', 'CCA 20-40 cm + B (tg) 1m', 'IX,XI'),
(73, 31, '', '0.4-0.1', '', '', '', 3, '4-12.5', 'd', 'CCA (sr) 30-50 cm + B (tg) 1m', 'VIII,X,XI'),
(74, 32, 'd', '0.4-0.1', '', '', '>= 20', 3, '11-34', 'a', 'B (tg) 1m + S (mr) 40-60 cm', 'II,IV,IX,XI'),
(75, 32, 'd', '0.4-0.1', '', '', '< 20', 3, '11-34', 'b', 'B (tg) 1m + S (mr) 20-40 cm ', 'III,IV,IX,XI'),
(76, 33, '', '0.1-0.01', '>= 2', '', '', 6, '1.0-3.9', 'a', 'B (tg) 1m + S (mr) 2.5-5cm', 'IX'),
(77, 33, '', '0.1-0.01', '< 2', '', '', 6, '1.0-3.9', 'b', 'S (mr) 5 ? 10 cm', 'IX'),
(78, 33, '', '0.1-0.01', '', '', '', 6, '1.0-3.9', 'c', 'S (mr) 7.5-15 cm', 'VIII,X'),
(79, 34, '', '0.1-0.01', '>= 2', '>= 0.25', '', 6, '2.0-11', 'a', 'B (tg) 1m + S (mr) 5-7.5 cm', 'IX'),
(80, 34, '', '0.1-0.01', '< 2', '<= 0.25', '', 6, '2.0-11', 'b', 'S (mr) 7.5-15 cm', 'IX'),
(81, 34, '', '0.1-0.01', '', '< 0.25', '', 6, '2.0-11', 'c', 'S (mr) 15-25 cm', 'IX'),
(82, 34, '', '0.1-0.01', '', '', '', 6, '2.0-11', 'd', 'CCA (sr) 20-60 cm + B (tg) 1m', 'VIII,X,XI'),
(83, 35, 'd', '0.1-0.01', '', '', '>= 15', 6, '6.2-28', 'a', 'B (tg) 1 m + S (mr) 30-100 cm', 'II,IX,XI'),
(84, 35, 'd', '0.1-0.01', '', '', '>= 15', 6, '6.2-28', 'b', 'CCA (sr) 60-200 cm + B (tg) 1 m', 'II,VIII,X,XI'),
(85, 35, 'd', '0.1-0.01', '', '', '< 15', 6, '6.2-28', 'c', 'B (tg) 1m + S (mr) 20-75cm', 'III,IX,XI'),
(86, 35, 'd', '0.1-0.01', '', '', '< 15', 6, '6.2-28', 'd', 'CCAa (sr) 40-150 cm + B (tg) 1 m', 'III,VIII,X,XI'),
(87, 36, '', '0.1-0.01', '', '', '', 12, '1.0-2.0', 'a', 'S (mr) 10-20 cm', 'IX'),
(88, 36, '', '0.1-0.01', '', '', '', 12, '1.0-2.0', 'b', 'S (mr) 10-20 cm + B (tg) 0.5-1.0 m', 'VIII,X,XI'),
(89, 37, '', '0.1-0.01', '', '', '', 12, '1.0-6.5', 'a', 'S (mr) 20-60 cm', 'IX'),
(90, 37, '', '0.1-0.01', '', '', '', 12, '1.0-6.5', 'b', 'S (mr) 20-60 cm + B (tg) 0.5-1.0 m', 'VIII,X,XI'),
(91, 38, 'e', '0.1-0.01', '', '', '>= 10', 12, '4.0-20', 'a', 'CCA (sr) 100-300 cm', 'IX'),
(92, 38, 'e', '0.1-0.01', '', '', '>= 10', 12, '4.0-20', 'b', 'CCA (sr) 100-300 cm + B (tg) 1 m', 'II,VIII,X,XI'),
(93, 38, 'e', '0.1-0.01', '', '', '< 10', 12, '4.0-20', 'c', 'S (mr) 70-200 cm', 'IX'),
(94, 38, 'e', '0.1-0.01', '', '', '< 10', 12, '4.0-20', 'd', 'S (mr) 70-200 cm', 'III,VIII,X,XI');

-- --------------------------------------------------------

--
-- Stand-in structure for view `result`
--
CREATE TABLE `result` (
`id` int(11)
,`username_admin` varchar(50)
,`date` datetime
,`location` text
,`rqd` float
,`jn` float
,`jr` float
,`ja` float
,`jw` float
,`srf` float
,`esr` float
,`b` float
,`ed` float
,`qresult` float
,`rmr_type` varchar(50)
,`rmr_result` float
,`l` float
,`spanmax` float
,`p_roof` float
,`cond_a` float
,`cond_b` float
,`q_table` int(11)
,`rmr_table` int(11)
,`username` varchar(50)
,`password` varchar(50)
,`name` varchar(50)
,`employee_number` varchar(30)
,`position` varchar(50)
,`email` varchar(50)
,`address` text
,`phone` varchar(20)
,`picture` varchar(50)
,`id_q` int(11)
,`support_category` int(11)
,`keterangan` varchar(20)
,`q_system` varchar(20)
,`conditional_a` varchar(20)
,`conditional_b` varchar(20)
,`span` varchar(20)
,`pb` int(11)
,`span_esr` varchar(20)
,`kode` varchar(20)
,`type_of_support` varchar(200)
,`notes` set('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII')
,`id_rmr` int(11)
,`rmr_class` varchar(3)
,`rmr_value` varchar(30)
,`rmr_classification` varchar(30)
,`avg_stand` varchar(50)
,`cohession` varchar(10)
,`angle` varchar(10)
,`bearing_pressure` varchar(20)
,`cut_slope` varchar(20)
,`penggalian` text
,`rockbolt` text
,`shotcrete` text
,`steelsets` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `resulta`
--
CREATE TABLE `resulta` (
`id` int(11)
,`username_admin` varchar(50)
,`date` datetime
,`location` text
,`rqd` float
,`jn` float
,`jr` float
,`ja` float
,`jw` float
,`srf` float
,`esr` float
,`b` float
,`ed` float
,`qresult` float
,`rmr_result` float
,`l` float
,`spanmax` float
,`p_roof` float
,`cond_a` float
,`cond_b` float
,`q_table` int(11)
,`rmr_table` int(11)
,`username` varchar(50)
,`password` varchar(50)
,`name` varchar(50)
,`employee_number` varchar(30)
,`position` varchar(50)
,`email` varchar(50)
,`address` text
,`phone` varchar(20)
,`picture` varchar(50)
,`id_q` int(11)
,`support_category` int(11)
,`keterangan` varchar(20)
,`q_system` varchar(20)
,`conditional_a` varchar(20)
,`conditional_b` varchar(20)
,`span` varchar(20)
,`pb` int(11)
,`span_esr` varchar(20)
,`kode` varchar(20)
,`type_of_support` varchar(200)
,`notes` set('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII')
,`id_rmr` int(11)
,`rmr_class` varchar(3)
,`rmr_value` varchar(30)
,`rmr_classification` varchar(30)
,`avg_stand` varchar(50)
,`cohession` varchar(10)
,`angle` varchar(10)
,`bearing_pressure` varchar(20)
,`cut_slope` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `resultb`
--
CREATE TABLE `resultb` (
`id` int(11)
,`username_admin` varchar(50)
,`date` datetime
,`location` text
,`rqd` float
,`jn` float
,`jr` float
,`ja` float
,`jw` float
,`srf` float
,`esr` float
,`b` float
,`ed` float
,`qresult` float
,`rmr_type` varchar(50)
,`rmr_result` float
,`l` float
,`spanmax` float
,`p_roof` float
,`cond_a` float
,`cond_b` float
,`q_table` int(11)
,`rmr_table` int(11)
,`username` varchar(50)
,`password` varchar(50)
,`name` varchar(50)
,`employee_number` varchar(30)
,`position` varchar(50)
,`email` varchar(50)
,`address` text
,`phone` varchar(20)
,`picture` varchar(50)
,`id_q` int(11)
,`support_category` int(11)
,`keterangan` varchar(20)
,`q_system` varchar(20)
,`conditional_a` varchar(20)
,`conditional_b` varchar(20)
,`span` varchar(20)
,`pb` int(11)
,`span_esr` varchar(20)
,`kode` varchar(20)
,`type_of_support` varchar(200)
,`notes` set('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII')
,`id_rmr` int(11)
,`rmr_class` varchar(3)
,`rmr_value` varchar(30)
,`rmr_classification` varchar(30)
,`avg_stand` varchar(50)
,`cohession` varchar(10)
,`angle` varchar(10)
,`bearing_pressure` varchar(20)
,`cut_slope` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `rmr`
--

CREATE TABLE `rmr` (
  `id_rmr` int(11) NOT NULL,
  `rmr_class` varchar(3) DEFAULT NULL,
  `rmr_value` varchar(30) NOT NULL,
  `rmr_classification` varchar(30) NOT NULL,
  `avg_stand` varchar(50) NOT NULL,
  `cohession` varchar(10) NOT NULL,
  `angle` varchar(10) NOT NULL,
  `bearing_pressure` varchar(20) NOT NULL,
  `cut_slope` varchar(20) NOT NULL,
  `penggalian` text NOT NULL,
  `rockbolt` text NOT NULL,
  `shotcrete` text NOT NULL,
  `steelsets` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rmr`
--

INSERT INTO `rmr` (`id_rmr`, `rmr_class`, `rmr_value`, `rmr_classification`, `avg_stand`, `cohession`, `angle`, `bearing_pressure`, `cut_slope`, `penggalian`, `rockbolt`, `shotcrete`, `steelsets`) VALUES
(1, 'I', '100-81', 'Very Good', '20 years for 15 m span', '>0.4', '>45', '600-440', '>70', 'Full Face, with 3 m digging progress', 'Nothing', 'Nothing', 'Nothing'),
(2, 'II', '80-61', 'Good', '1 year for 10 m span', '0.3-0.4', '35-45', '440-280', '65', 'Full Face, with progress 1-1.5 m. Complete buffer 20 m from face', 'Localization, bolts on the roof along the 3 m sometimes with wire mesh', '50 mm on the roof', 'Nothing'),
(3, 'III', '60-41', 'Fair', '1 week for 5 m span', '0.2-0.3', '25-35', '280-135', '55', 'Top heading and bench, with progress of 1.5-3 m. Buffering starts after blasting and 10 m from the face', 'Systematic Bolt 4 m long with 1.5-2 m spaces on the roof and on the wall. On the roof is made with wire mesh', '20 - 100 mm on the roof and 30 mm on the sides', 'Nothing'),
(4, 'IV', '40-21', 'Poor', '10 hours for 2.5 span', '0.1-0.2', '15-25', '135-45', '45', 'Top headings and benches, with progress 1-1.5 m at the top headings, buffer every 10 m from the face', 'Bolt systematically 4-5 m long with 1-1.5 m spaces on the roof and on the walls with wire mesh', '100 - 150 mm on the roof and 100 mm on the sides', 'Mild to moderate ribs with 1.5 m of space'),
(5, 'V', '<20', 'Very Poor', '30 inutes for 1 m span', '<0.1', '<15', '45-30', '<40', 'Multiple drifts with progress 0.5-1.5 m at the top heading. Make a buffer for each multiplication. Shotcrete is immediately installed after blasting', 'Bolt sistematis panjang 5-6 m dengan spasi 1-1.5 m di atap dan di dinding dengan wire mesh. Buat bolt di lantai (invert)', '150 - 200 mm on the roof, 150 mm on the sides, and 50 mm on the face', 'Medium-heavy ribs with 0.75 m of space with steel lagging and forepoling'),
(6, '0', '<0', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Nothing', 'Nothing', 'Nothing', 'Nothing');

-- --------------------------------------------------------

--
-- Table structure for table `rqd_table`
--

CREATE TABLE `rqd_table` (
  `id_rqd` int(11) NOT NULL,
  `rqd` varchar(30) NOT NULL,
  `quality` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rqd_table`
--

INSERT INTO `rqd_table` (`id_rqd`, `rqd`, `quality`) VALUES
(1, '0-25', 'Very Poor'),
(2, '25-50', 'Poor'),
(3, '50-75', 'Fair'),
(4, '75-90', 'Good'),
(5, '90-100', 'Excellent');

-- --------------------------------------------------------

--
-- Table structure for table `srf_table`
--

CREATE TABLE `srf_table` (
  `id_srf` int(11) NOT NULL,
  `srf_kode` varchar(1) NOT NULL,
  `srf_description` text NOT NULL,
  `srf_value` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `srf_table`
--

INSERT INTO `srf_table` (`id_srf`, `srf_kode`, `srf_description`, `srf_value`) VALUES
(1, 'A', 'Single-weakness zones containing clay or chemically disintegrated rock, very loose surrounding rock (any depth). (Zona kelemahan tunggal yang mengandung tanah liat atau batuan yang terurai secara kimia, batuan di sekitarnya sangat longgar (kedalaman apa pun))', '10'),
(2, 'B', 'Single-weakness zones containing clay or chemically disintegrated rock (depth of excavation < 50 m). (Zona kelemahan tunggal yang mengandung tanah liat atau batuan yang terurai secara kimiawi )', '5'),
(3, 'C', 'Single-weakness zones containing clay or chemically disintegrated rock (depth of excavation > 50 m). (\nZona kelemahan tunggal yang mengandung tanah liat atau batuan yang terurai secara kimiawi )', '2.5'),
(4, 'D', 'Multiple-shear zones in cometent rock (clay-free), loose surrounding rock (any depth). (Beberapa zona geser pada batuan, batuan di sekitarnya yang longgar )', '7.5'),
(5, 'E', 'Single-shear zones in competent rock (clay-free) (depth of excavation < 50 m). (Zona geser-tunggal pada batuan kompeten)', '5'),
(6, 'F', 'Single-shear zones in competent rock (clay-free) (depth of excavation >50 m). (Zona geser-tunggal pada batuan kompeten )', '2.5'),
(7, 'G', 'Loose open joints, heavily jointed or ?sugar cube? etc. (any depth). (Sambungan terbuka yang longgar, bersendi banyak)', '5'),
(8, 'H', 'Low stress near surface. (tekanan rendah di dekat permukaan)', '2.5'),
(9, 'J', 'Medium stress (Tekanan Sedang)', '1'),
(10, 'K', 'High-stress, very tight structure (usually favorable to stability, may be unfavorable to wall stability). (Stres tinggi, struktur sangat ketat)', '0.5 - 2.0'),
(11, 'L', 'Mild rock burst (massive rock). (Semburan batu ringan (batu besar))', '5 - 10'),
(12, 'M', 'Heavy rock burst (massive rock). (Semburan batu berat (batu besar))', '10 - 20'),
(13, 'N', 'Mild squeezing rock pressure. (Tekanan batu ringan)', '5 - 10'),
(14, 'O', 'Heavy squeezing rock pressure (Tekanan batu berat)', '10 - 20'),
(15, 'P', 'Mild swelling rock pressure. (Tekanan pembengkakan batu ringan)', '5 - 10'),
(16, 'R', 'Heavy swelling rock pressure. (Tekanan pembengkakan batu berat)', '10 - 15');

-- --------------------------------------------------------

--
-- Structure for view `result`
--
DROP TABLE IF EXISTS `result`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `result`  AS  select `d`.`id` AS `id`,`d`.`username_admin` AS `username_admin`,`d`.`date` AS `date`,`d`.`location` AS `location`,`d`.`rqd` AS `rqd`,`d`.`jn` AS `jn`,`d`.`jr` AS `jr`,`d`.`ja` AS `ja`,`d`.`jw` AS `jw`,`d`.`srf` AS `srf`,`d`.`esr` AS `esr`,`d`.`b` AS `b`,`d`.`ed` AS `ed`,`d`.`qresult` AS `qresult`,`d`.`rmr_type` AS `rmr_type`,`d`.`rmr_result` AS `rmr_result`,`d`.`l` AS `l`,`d`.`spanmax` AS `spanmax`,`d`.`p_roof` AS `p_roof`,`d`.`cond_a` AS `cond_a`,`d`.`cond_b` AS `cond_b`,`d`.`q_table` AS `q_table`,`d`.`rmr_table` AS `rmr_table`,`e`.`username` AS `username`,`e`.`password` AS `password`,`e`.`name` AS `name`,`e`.`employee_number` AS `employee_number`,`e`.`position` AS `position`,`e`.`email` AS `email`,`e`.`address` AS `address`,`e`.`phone` AS `phone`,`e`.`picture` AS `picture`,`q`.`id_q` AS `id_q`,`q`.`support_category` AS `support_category`,`q`.`keterangan` AS `keterangan`,`q`.`q_system` AS `q_system`,`q`.`conditional_a` AS `conditional_a`,`q`.`conditional_b` AS `conditional_b`,`q`.`span` AS `span`,`q`.`pb` AS `pb`,`q`.`span_esr` AS `span_esr`,`q`.`kode` AS `kode`,`q`.`type_of_support` AS `type_of_support`,`q`.`notes` AS `notes`,`r`.`id_rmr` AS `id_rmr`,`r`.`rmr_class` AS `rmr_class`,`r`.`rmr_value` AS `rmr_value`,`r`.`rmr_classification` AS `rmr_classification`,`r`.`avg_stand` AS `avg_stand`,`r`.`cohession` AS `cohession`,`r`.`angle` AS `angle`,`r`.`bearing_pressure` AS `bearing_pressure`,`r`.`cut_slope` AS `cut_slope`,`r`.`penggalian` AS `penggalian`,`r`.`rockbolt` AS `rockbolt`,`r`.`shotcrete` AS `shotcrete`,`r`.`steelsets` AS `steelsets` from (((`data` `d` join `employee` `e` on((`d`.`username_admin` = `e`.`username`))) join `q_system` `q` on((`d`.`q_table` = `q`.`id_q`))) join `rmr` `r` on((`d`.`rmr_table` = `r`.`id_rmr`))) ;

-- --------------------------------------------------------

--
-- Structure for view `resulta`
--
DROP TABLE IF EXISTS `resulta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `resulta`  AS  select `d`.`id` AS `id`,`d`.`username_admin` AS `username_admin`,`d`.`date` AS `date`,`d`.`location` AS `location`,`d`.`rqd` AS `rqd`,`d`.`jn` AS `jn`,`d`.`jr` AS `jr`,`d`.`ja` AS `ja`,`d`.`jw` AS `jw`,`d`.`srf` AS `srf`,`d`.`esr` AS `esr`,`d`.`b` AS `b`,`d`.`ed` AS `ed`,`d`.`qresult` AS `qresult`,`d`.`rmr_result` AS `rmr_result`,`d`.`l` AS `l`,`d`.`spanmax` AS `spanmax`,`d`.`p_roof` AS `p_roof`,`d`.`cond_a` AS `cond_a`,`d`.`cond_b` AS `cond_b`,`d`.`q_table` AS `q_table`,`d`.`rmr_table` AS `rmr_table`,`e`.`username` AS `username`,`e`.`password` AS `password`,`e`.`name` AS `name`,`e`.`employee_number` AS `employee_number`,`e`.`position` AS `position`,`e`.`email` AS `email`,`e`.`address` AS `address`,`e`.`phone` AS `phone`,`e`.`picture` AS `picture`,`q`.`id_q` AS `id_q`,`q`.`support_category` AS `support_category`,`q`.`keterangan` AS `keterangan`,`q`.`q_system` AS `q_system`,`q`.`conditional_a` AS `conditional_a`,`q`.`conditional_b` AS `conditional_b`,`q`.`span` AS `span`,`q`.`pb` AS `pb`,`q`.`span_esr` AS `span_esr`,`q`.`kode` AS `kode`,`q`.`type_of_support` AS `type_of_support`,`q`.`notes` AS `notes`,`r`.`id_rmr` AS `id_rmr`,`r`.`rmr_class` AS `rmr_class`,`r`.`rmr_value` AS `rmr_value`,`r`.`rmr_classification` AS `rmr_classification`,`r`.`avg_stand` AS `avg_stand`,`r`.`cohession` AS `cohession`,`r`.`angle` AS `angle`,`r`.`bearing_pressure` AS `bearing_pressure`,`r`.`cut_slope` AS `cut_slope` from (((`data` `d` join `employee` `e` on((`d`.`username_admin` = `e`.`username`))) join `q_system` `q` on((`d`.`q_table` = `q`.`id_q`))) join `rmr` `r` on((`d`.`rmr_table` = `r`.`id_rmr`))) ;

-- --------------------------------------------------------

--
-- Structure for view `resultb`
--
DROP TABLE IF EXISTS `resultb`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `resultb`  AS  select `d`.`id` AS `id`,`d`.`username_admin` AS `username_admin`,`d`.`date` AS `date`,`d`.`location` AS `location`,`d`.`rqd` AS `rqd`,`d`.`jn` AS `jn`,`d`.`jr` AS `jr`,`d`.`ja` AS `ja`,`d`.`jw` AS `jw`,`d`.`srf` AS `srf`,`d`.`esr` AS `esr`,`d`.`b` AS `b`,`d`.`ed` AS `ed`,`d`.`qresult` AS `qresult`,`d`.`rmr_type` AS `rmr_type`,`d`.`rmr_result` AS `rmr_result`,`d`.`l` AS `l`,`d`.`spanmax` AS `spanmax`,`d`.`p_roof` AS `p_roof`,`d`.`cond_a` AS `cond_a`,`d`.`cond_b` AS `cond_b`,`d`.`q_table` AS `q_table`,`d`.`rmr_table` AS `rmr_table`,`e`.`username` AS `username`,`e`.`password` AS `password`,`e`.`name` AS `name`,`e`.`employee_number` AS `employee_number`,`e`.`position` AS `position`,`e`.`email` AS `email`,`e`.`address` AS `address`,`e`.`phone` AS `phone`,`e`.`picture` AS `picture`,`q`.`id_q` AS `id_q`,`q`.`support_category` AS `support_category`,`q`.`keterangan` AS `keterangan`,`q`.`q_system` AS `q_system`,`q`.`conditional_a` AS `conditional_a`,`q`.`conditional_b` AS `conditional_b`,`q`.`span` AS `span`,`q`.`pb` AS `pb`,`q`.`span_esr` AS `span_esr`,`q`.`kode` AS `kode`,`q`.`type_of_support` AS `type_of_support`,`q`.`notes` AS `notes`,`r`.`id_rmr` AS `id_rmr`,`r`.`rmr_class` AS `rmr_class`,`r`.`rmr_value` AS `rmr_value`,`r`.`rmr_classification` AS `rmr_classification`,`r`.`avg_stand` AS `avg_stand`,`r`.`cohession` AS `cohession`,`r`.`angle` AS `angle`,`r`.`bearing_pressure` AS `bearing_pressure`,`r`.`cut_slope` AS `cut_slope` from (((`data` `d` join `employee` `e` on((`d`.`username_admin` = `e`.`username`))) join `q_system` `q` on((`d`.`q_table` = `q`.`id_q`))) join `rmr` `r` on((`d`.`rmr_table` = `r`.`id_rmr`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `q_table` (`q_table`),
  ADD KEY `rmr_table` (`rmr_table`),
  ADD KEY `username_admin` (`username_admin`);

--
-- Indexes for table `dataku`
--
ALTER TABLE `dataku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `esr_table`
--
ALTER TABLE `esr_table`
  ADD PRIMARY KEY (`id_esr`);

--
-- Indexes for table `ja_table`
--
ALTER TABLE `ja_table`
  ADD PRIMARY KEY (`id_ja`);

--
-- Indexes for table `jn_table`
--
ALTER TABLE `jn_table`
  ADD PRIMARY KEY (`id_jn`);

--
-- Indexes for table `jr_table`
--
ALTER TABLE `jr_table`
  ADD PRIMARY KEY (`id_jr`);

--
-- Indexes for table `jw_table`
--
ALTER TABLE `jw_table`
  ADD PRIMARY KEY (`id_jw`);

--
-- Indexes for table `q_notes`
--
ALTER TABLE `q_notes`
  ADD PRIMARY KEY (`notes_number`);

--
-- Indexes for table `q_system`
--
ALTER TABLE `q_system`
  ADD PRIMARY KEY (`id_q`);

--
-- Indexes for table `rmr`
--
ALTER TABLE `rmr`
  ADD PRIMARY KEY (`id_rmr`);

--
-- Indexes for table `rqd_table`
--
ALTER TABLE `rqd_table`
  ADD PRIMARY KEY (`id_rqd`);

--
-- Indexes for table `srf_table`
--
ALTER TABLE `srf_table`
  ADD PRIMARY KEY (`id_srf`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `dataku`
--
ALTER TABLE `dataku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `esr_table`
--
ALTER TABLE `esr_table`
  MODIFY `id_esr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ja_table`
--
ALTER TABLE `ja_table`
  MODIFY `id_ja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `jn_table`
--
ALTER TABLE `jn_table`
  MODIFY `id_jn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `jr_table`
--
ALTER TABLE `jr_table`
  MODIFY `id_jr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `jw_table`
--
ALTER TABLE `jw_table`
  MODIFY `id_jw` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `rmr`
--
ALTER TABLE `rmr`
  MODIFY `id_rmr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `rqd_table`
--
ALTER TABLE `rqd_table`
  MODIFY `id_rqd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `srf_table`
--
ALTER TABLE `srf_table`
  MODIFY `id_srf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `data`
--
ALTER TABLE `data`
  ADD CONSTRAINT `data_ibfk_2` FOREIGN KEY (`q_table`) REFERENCES `q_system` (`id_q`),
  ADD CONSTRAINT `data_ibfk_3` FOREIGN KEY (`rmr_table`) REFERENCES `rmr` (`id_rmr`),
  ADD CONSTRAINT `data_ibfk_4` FOREIGN KEY (`username_admin`) REFERENCES `employee` (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
